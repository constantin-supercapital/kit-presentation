# Kit Supports Super Capital — V4 (04/11/2026)

Kit de production des supports Super Capital avec Claude, **dédié en priorité aux présentations commerciales** (format des prez Reprise et DAF à temps partagé). Carrousels, posts et miniatures restent possibles.
À joindre au début de chaque conversation du projet « Support de communication rebrandé ».

## Démarrer une prez commerciale

1. Claude lit `charte.md` (section 0) et `contenus.md`.
2. Claude propose un déroulé slide par slide avec le gabarit imité ; Constantin valide.
3. Claude produit la prez dans **Claude Slides** (livrable par défaut, export PDF et PowerPoint) en partant des slides validées de `gabarits/claude-slides/` et des gabarits HTML (`prez-commerciale-gabarits.html` pour une offre, `prez-ts-daf-gabarits.html` pour un client), puis vérifie chaque slide. Un PDF rendu par Chromium n’est produit que sur demande.

## Contenu

```
charte.md            Règles, méthode, catalogue des gabarits, décisions validées, refus (à lire en premier)
contenus.md          Chiffres officiels, équipe, bios, contacts, citations, contenus validés des prez DAF et TS & DAF
JOURNAL.md           Journal des versions du kit
fonts/               Satoshi Bold et Medium, Sentient Italic et Bold (TTF + OTF d’origine)
gabarits/
  _base.css                       Feuille de style commune
  prez/prez-commerciale-gabarits.html   11 gabarits de prez validés (P-COUV, P-MISSION, P-OFFRE,
                                  P-SERVICE et sa variante dispositifs, P-FRISE, P-TEMOIGNAGES,
                                  P-SECTEURS et P-SECTEURS 8 secteurs, P-TARIFS, P-CONTACTS)
  prez/prez-financement-startups.html   Prez Financement des startups V4 validée (exemple complet)
  prez/prez-ts-daf-gabarits.html  Prez client TS & DAF en 15 pages : + P-CHIFFRES, P-DEJA, P-EQUIPE,
                                  P-THEMES, P-SYNTHESE, P-OPERATIONS ; exemple Isatis Capital (V16)
  prez/brouillon-p-clients.html   P-CLIENTS (Groupe 10), non validé, hors catalogue
  claude-slides/                  Prez Reprise V2 validée au format Claude Slides (17 slides, deck.json)
                                  + README : correspondance des assets, gabarits P-MARCHE, P-VISION,
                                  P-INTERVENTION, P-PRICING
  planche-composants.html         Planche des composants de base
scripts/
  rendu.py           HTML → PDF/PNG avec Chromium, contrôles automatiques
  aplatir.py         Aplatit un logo transparent sur une couleur de fond
  logos.py           Logo monochrome aplati + taille à poids visuel égal (P-SECTEURS)
  otf2ttf.py, vectoriser.py
assets/
  logos/             Logo horizontal et icône en SVG (noir, menthe, orange) + originaux
  pictos/            Flèches → et ↗ en SVG
  pattern/           Pattern_Orange4x.png (réduit à 1960 px depuis l’original), Pattern_Bleu.png et Pattern_Bordeaux.png (1400 px)
  photos-equipe/     Photos carrées de l’équipe (prénom-nom)
  claude-slides/     Pattern orange en JPG et fond de couverture Reprise, pour Claude Slides
  photos-citation/   Portrait de Frédéric et photo Frédéric + Cyril (originaux + versions avec dégradé intégré), pour la slide Mission
  logos-clients/     Logos clients et références monochromes : sur-menthe/, sur-blanc/, sur-orange/, sources/ ;
                     logos Isatis Capital en SVG (noir et menthe)
  photos-evenements/, extraits-references-2026/, extraits-prez-janvier-2026/, references/
apercus/
  Prez_Reprise_V2_validee.pdf     Prez Reprise validée le 04/11/2026 (Claude Slides) + planche
  *-planche.jpg                   Planches des prez DAF V8, TS & DAF Isatis (V16) et Financement des startups (V4) ;
                                  leurs PDF sont dans les fichiers du projet (retirés du kit pour rester sous 25 Mo)
```

Les PDF de référence (prez Groupe, prez Reprise, carrousel V25) restent dans les fichiers du projet, avec la prez DAF V8.

## Rendre un support

```bash
pip install playwright --break-system-packages   # si besoin
python3 scripts/rendu.py gabarits/prez/prez-commerciale-gabarits.html sorties/Prez_V1.pdf --png sorties/png/
```

## Limites connues

- Les images extraites des PDF Canva sont plafonnées à environ 800 px. Pour un grand format, demander les originaux.
- Gabarits encore à créer (à la première utilisation, puis à valider) : marché, intervention numérotée, tableau de pricing, logos par catégorie (brouillon P-CLIENTS), frise à 6 étapes.
