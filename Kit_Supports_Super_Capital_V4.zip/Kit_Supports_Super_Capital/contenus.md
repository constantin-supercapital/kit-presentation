# Contenus officiels Super Capital — Kit V4 (04/11/2026)

Source : prez Groupe et prez Reprise (Branding 2026, exports PDF d’octobre 2026) et prez DAF à temps partagé V8 et prez « Exemple_TS_DAF_Isatis » (V16, validées le 28/10/2026), et prez Financement des startups (V4, validée le 29/10/2026). Ces contenus font foi.
Pour une personnalisation (secteur, client, rendez-vous), demander à Constantin les chiffres du site supercapital.fr.
Ne jamais compléter ni arrondir un chiffre sans validation.

## Signature

- Baseline : « Le partenaire financier intégral des entrepreneurs » (couverture prez Groupe).
- Site : supercapital.fr. Mention légale : « © 2026 SUPER CAPITAL. Tous droits réservés. »

## Chiffres groupe

| Chiffre | Libellé |
|---|---|
| 100 M€ | Financements obtenus |
| 350+ | Entrepreneurs accompagnés |
| 200+ | Sociétés en portefeuille |
| 2 000+ | Investisseurs engagés |
| 8 ans | Au service des entrepreneurs |

## Chiffres marché startup

| Chiffre | Libellé |
|---|---|
| 60 M€ | Levés pour nos clients startup |
| 250+ | Entrepreneurs accompagnés |
| 15 ans | D’expertise dans l’écosystème tech |
| 200+ | Startups dans notre portefeuille |

## Chiffres marché PME

| Chiffre | Libellé |
|---|---|
| 40 M€ | Levés pour nos clients PME |
| 150+ | Dirigeants accompagnés |
| 15 ans | D’expérience en direction financière PME & ETI |
| 45+ | Cessions et acquisitions conseillées |

## Chiffres reprise

| Chiffre | Libellé |
|---|---|
| 50+ | Transactions réalisées (prez Reprise V2, validé le 04/11/2026) |
| 400+ | Due diligences réalisées |
| 2 000+ | Investisseurs engagés |
| 100+ | Banques et fonds partenaires |
| 370 000 | Entreprises à reprendre d’ici 2030 (source : BPI France) |
| × 3+ | D’entreprises à transmettre que de repreneurs accompagnés |
| 20-35 % / 65-80 % | Part apport + club deal et fonds / part dette et financements non-dilutifs dans un montage type |
| 6 à 12 mois | Durée d’une reprise clé en main |
| 1 à 5 M€ | Valeur de transaction ciblée |

Opérations réalisées (slide 12 de la prez Reprise) : Projets médias, Maranello Europe, Hugotte, Projet D18NOW. Reprendre les chiffres exacts de la slide.

## Équipe et fonctions (slide équipe de la prez Groupe)

| Nom | Fonction | Photo |
|---|---|---|
| Frédéric Baecke | Co-fondateur & Président | frederic-baecke.jpg (carrée) ; portrait `photos-citation/frederic-baecke-portrait.jpg`, réservé à la slide Mission / Légitimité |
| Thibaut Gimenez | Co-fondateur & Managing Partner | thibaut-gimenez.jpg |
| Charles Garcia | Partner - Responsable marché PME (depuis le 04/11/2026) | charles-garcia.jpg |
| Gaspard de Buchet | Responsable marché startup | gaspard-de-buchet.jpg |
| Cyril Doukhan | Senior Partner Transaction services | cyril-doukhan.jpg (480 px) |
| Jean-Philippe Aumercier | Senior Partner Dév. commercial | jean-philippe-aumercier.jpg (240 px) |
| Ruthy Bendavid | Responsable fiscalité de l’innovation | ruthy-bendavid.jpg |
| Juliette Muller | Experte fiscalité & financement innovation | juliette-muller.jpg |
| Alix Riou du Cosquer | DAF externalisé & Transaction services | alix-riou-du-cosquer.jpg |
| Théo Renault | DAF externalisé & Transaction services | theo-renault.jpg |
| Jeanne Voisin | Chargée d’affaires financements | jeanne-voisin.jpg |
| Alexis Mercier | Chargé d’affaires financements (« Chargée » dans le deck, à vérifier) | alexis-mercier.jpg |
| Arthur Florin | Analyste financements | arthur-florin.jpg |
| Anna Bottlaender | Analyste financements | anna-bottlaender.jpg |
| Baptiste Weissgerber | Analyste fusion-acquisition | baptiste-weissgerber.jpg |
| Romain Calco | Chargé développement marché PME | romain-calco.jpg |
| Ulysse Bedeau | Chargé développement marché startup | ulysse-bedeau.jpg |
| Élodie Deleglise | Chargée développement marché startup | elodie-deleglise.jpg |
| Maximilien Delorme | Chargé développement marché startup | maximilien-delorme.jpg |
| Constantin Pierrot | Communication, marketing & RP | constantin-pierrot.jpg |

Prez Reprise : « 40 ans d’expérience cumulée en direction financière et en transaction services », « +17 membres de l’équipe Super Capital ».

### Bios validées

- Frédéric Baecke (prez Reprise) : « Fort de près de 20 ans d’expérience en finance d’entreprise, Frédéric devient Directeur Financier à 27 ans. Il porte aujourd’hui une ambition : faire de Super Capital le partenaire de finance intégrale des entrepreneurs, avec une finance au service des opérations et de la croissance des entreprises. »
- Cyril Doukhan (prez Reprise) : « Fort de plus de 30 ans d’expérience en finance, dont près de 20 ans chez Grant Thornton, Cyril accompagne dirigeants et investisseurs dans leurs opérations d’acquisition, de cession et de transformation. »
- Cyril Doukhan (prez TS & DAF, version longue avec les dates des decks sources) : « Fort de plus de 30 ans d’expérience en finance, dont près de 20 ans chez Grant Thornton, Cyril a fondé ACD Conseils en 2013 puis 64 Finance en 2020. Il accompagne dirigeants et investisseurs dans leurs opérations d’acquisition, de cession et de transformation. »
- Alix Riou du Cosquer (prez TS & DAF) : « Fort d’une expérience chez KPMG France et AYA Partners, Alix structure le pilotage financier de nos clients (reporting, trésorerie, prévisionnel) et intervient sur les missions de transaction services. » (orthographe d’AYA Partners à confirmer)
- Théo Renault (prez TS & DAF) : « Fort d’une expérience chez Allianz Global, CIC Market Solutions et KPMG Singapour, Théo met en place les outils de pilotage et sécurise la trésorerie, jusqu’aux missions de transaction services. » (nom complet d’Allianz à confirmer)

## Contacts (présentations commerciales confidentielles uniquement)

| Nom | Fonction | E-mail | Téléphone |
|---|---|---|---|
| Frédéric Baecke | Co-fondateur & Président | fred.ba@supercapital.vc | +33 6 46 61 18 46 |
| Thibaut Gimenez | Co-fondateur & Managing Partner | thibaut@supercapital.vc | +33 6 78 56 55 19 |
| Charles Garcia | Partner - Responsable marché PME | charles@supercapital.vc | +33 6 30 64 25 72 |
| Gaspard de Buchet | Responsable marché startup | gaspard@supercapital.vc | +33 7 83 20 15 68 |
| Cyril Doukhan | Senior Partner Transaction services | cyril.doukhan@supercapital.vc | +33 6 23 06 69 83 |

## Citations validées

Toujours entre guillemets “ ” (décision du 28/10/2026).


- Frédéric Baecke : “La finance doit être au service des opérations et des entrepreneurs.” (le deck écrit “doit être service des”, coquille corrigée)
- Frédéric Baecke : “Chaque projet de reprise est une aventure entrepreneuriale. Nous faisons de la finance un atout au service d’une stratégie de développement et d’une vision portée par l’entrepreneur.”
- Charles Garcia, Partner - Responsable marché PME (slide Vision de la prez Reprise V2, **à faire valider par Charles**) : “Chaque projet de reprise est une aventure entrepreneuriale. Nous faisons de la finance un atout au service d’une stratégie de développement et d’une vision portée par le repreneur, qui doit avant tout être un entrepreneur.”
- Eric Werner, repreneur & dirigeant de Hugotte (signature : « /Eric WERNER/ », « Repreneur & dirigeant @ Hugotte ») : “Aujourd’hui, je suis propriétaire de mon entreprise, je me rémunère, et je développe une société qui me plaît énormément.”
- Léonard Grynfogel, co-fondateur & CEO de Luniwave : “Je visais entre 500 k et 1 M€ de financements […], et au final on a eu 1,4 M€ […] on a eu des aides et des subventions régionales ! Super Capital en 3 mots : Efficacité, confiance, transparence.”
- Paul Rousseau, co-fondateur & CEO de Bloomcare : “Je visais environ 150 k€ […] et finalement on fait 400 k€ […] Super Capital a réussi à trouver les bons interlocuteurs, changer de délégation pour permettre de maximiser ce que l’on pouvait obtenir.”
- Gaspard de Buchet, Responsable marché startup : “Mon métier : que la finance ne freine jamais l’innovation.” (slide Mission de la prez Financement des startups, portrait `photos-citation/gaspard-de-buchet-portrait-degrade.jpg`)
- Jérôme Bourreau, fondateur & CEO d’Anamnèse : “L’un des gros points forts de Super Capital, c’est de guider. […] La notion d’accompagnement est extrêmement forte. […] Ça me diminue la charge de travail, et que ça puisse être le plus simple possible pour moi.”

## Prez DAF à temps partagé (validée le 28/10/2026, V8)

Source : Google Slides « SUPER CAPITAL - Offre DAF à temps partagé », rebrandé. Les contacts de la prez sont ceux du tableau Contacts ci-dessus (Frédéric Baecke, Charles Garcia, Gaspard de Buchet).

- **Couverture** : « /DIRECTION FINANCIÈRE À TEMPS PARTAGÉ/ », sous-titre « Gestion financière, cash management et transaction services ». Étiquettes : « Direction financière externalisée » (lien https://www.supercapital.fr/expertises/direction-financiere-daf) et « Transaction services » (lien https://www.supercapital.fr/expertises/audit-ts).
- **Légitimité** : titre « /Une vision de la finance au service des opérations/ ». Texte : « Forts de près de 20 années d’expérience en direction financière et en financement des entreprises, nous offrons une combinaison de services de banque d’affaires et de DAF à temps partagé résolument opérationnelle, afin d’aider les dirigeants à structurer leur développement et à prendre les meilleures décisions stratégiques. » « Près de 20 années » est validé **exceptionnellement pour cette prez** : ce n’est pas un chiffre officiel (comparer : « 15 ans d’expérience en direction financière PME & ETI »).
- **Offre** : titre « /Structurer votre fonction finance pour libérer tout le potentiel de votre business ».

### Services (accroches et blocs)

| Offre | Accroche (panneau) | Blocs |
|---|---|---|
| Gestion financière (orange) | Donner à votre entreprise une base financière solide et un reporting fiable pour transformer la fonction finance en véritable levier de performance et de décision. | Visibilité ; Optimisation et anticipation ; Analyses claires et actionnables |
| Cash management (bleu) | Maîtriser vos flux financiers pour soutenir la croissance et limiter les risques. Cash is King. | Suivi ; Outils fiables ; Anticipation et planification |
| Transaction services (bordeaux) | Accompagner vos opérations stratégiques et vos levées de fonds pour sécuriser vos décisions et maximiser vos chances de succès. | Levée de fonds et croissance externe ; Stress tests et scénarios financiers ; Analyses adaptées aux investisseurs |

Questions et réponses des blocs : voir `gabarits/prez/prez-commerciale-gabarits.html` (slides 4 à 6).

**À réécrire** : la question “Mon suivi budgétaire et mes prévisions me permettent-ils d’anticiper mes besoins de trésorerie et de simuler différents scénarios (nouveaux clients, ralentissement) ?” apparaît deux fois (Optimisation et anticipation, Stress tests et scénarios financiers).

### Offres, durées et tarifs

| Offre | Phrase d’objectif | Durée estimée | Précision |
|---|---|---|---|
| 1. Audit | Diagnostiquer votre organisation, vos process et vos outils pour fixer les priorités. | 1 à 5 jours | mission ponctuelle |
| 2. Build | Construire les process, les outils et les budgets qui renforcent votre visibilité financière. | 5 à 10 jours | reporting, plus 5 jours pour le budget |
| 3. Run | Piloter votre finance dans la durée, soutenir vos décisions et faire évoluer les process avec l’entreprise. | 1 à 5 jours / mois | selon le besoin |

- TJM de base : **950 € HT / jour** ; missions stratégiques : **1 200 € HT / jour**.
- Facturation : « Facturation mensuelle selon le temps passé, ou forfait sur une durée et un budget déterminés. »
- Le périmètre détaillé de chaque offre est dans le gabarit (slide 8).

### Clients DAF par secteur (secteurs du site)

| Secteur du site | Clients |
|---|---|
| AI & Software | muchbetter.ai, Symfony, adesoft |
| Retail & E-commerce | Cigoire, Pix Box, The Fat Broccoli |
| Industrie & Énergie | Geolinks, Le Pavé, Lemontri |
| Services aux entreprises | Maranello, Umanlink |
| Médias, Gaming & Entertainment | Plume, Anybuddy |

**À corriger dans le CMS du site** (collection References) :
- Anybuddy, Le Pavé et Lemontri : présents sans l’offre « Direction financière à temps-partagé ».
- Umanlink : absent du CMS ; classé par Claude dans Services aux entreprises (activité RH).
- Reekom, Bar à Encres, C-Clerc, Nimesis (brouillon) : étiquetés DAF sur le site mais absents de la prez.

## Prez TS & DAF à temps partagé (« Exemple_TS_DAF_Isatis », V16 validée le 28/10/2026)

Gabarits : `gabarits/prez/prez-ts-daf-gabarits.html`. Pages [PERSO] : couverture (client, mois, logo), « À vos côtés », « Vos thématiques », secteur prioritaire, choix des opérations.

### Chiffres clés (page 03)

| Chiffre | Libellé | Statut |
|---|---|---|
| 400+ | Due diligences réalisées par nos associés | Chiffre officiel (Reprise), attribué aux associés |
| 1998 | Premières opérations menées par nos associés | Début du track record de Cyril Doukhan |
| 15+ | Secteurs d’intervention | Source à confirmer |

### Textes validés

- Couverture : « /Transaction services & direction financière à temps partagé/ », sous-titre « Proposition pour [Client] · [Mois année] ».
- Conviction : titre « /Le conseil financier senior au cœur de chaque transformation/ » ; texte « Les PME et ETI qui se transforment, par acquisition, cession ou restructuration, ont besoin d’un conseil financier senior, réactif et totalement aligné sur leurs enjeux opérationnels. Notre connaissance intime du marché Small Cap, forgée depuis plus de 20 ans aux côtés de dirigeants exigeants, garantit un dialogue de confiance à chaque étape. » (« plus de 20 ans » non officiel).
- Valeur ajoutée : accroche « Une tarification transparente, une équipe pluridisciplinaire et des solutions à forte valeur ajoutée dédiées aux investisseurs, financiers, dirigeants et entrepreneurs. » ; blocs Spécialiste Small Cap, Associés seniors impliqués, Honoraires compétitifs.
- Services : titre « /Accompagner fonds d’investissement et corporates dans la sécurisation de leurs opérations ».
- Accroches des pages service : DD d’acquisition « Sécuriser et optimiser la transaction » ; VDD « Optimiser et simplifier le process de l’opération » ; DAF « Une compétence senior sans le coût d’un DAF à temps plein ». Blocs Objectifs / Réalisations / Vos bénéfices (DAF : Évaluer & piloter / Structurer & accompagner / Vos bénéfices), textes de l’exemple.
- Track record (source : Cyril Doukhan au 12/10/2026, 502 missions — Grant Thornton Transaction Services, puis ACD Conseils, 64 Finance et Aequido), missions par secteur : Industrie, BTP & immobilier 101 ; Distribution & retail 90 ; Services aux entreprises 63 ; ESN, digital & logiciels 50 ; Agroalimentaire 43 ; Médias & communication 41 ; Santé, pharma & cosmétique 32 ; Transport & logistique 31 ; Hôtellerie-restauration 25 ; RH, intérim & portage 24.
- Opérations marquantes : Proman Embarq (DD, 127 M€, Groupe Proman, 2024) ; Aksis (accompagnement, 100 M€, Groupe Proman, 2022) ; Groupe Sucheme (DAF à temps partagé, 100 M€, dirigeant, 2020) ; P2I (VDD, 77 M€, cédant, 2022).
- Références des associés (bande : « Une sélection de sociétés accompagnées par nos associés au cours de leur carrière ») : AI & Software (Linedata, Vocalcom, Proservia), Retail & E-commerce (Carrefour, Mr.Bricolage, Nocibé), Industrie & Énergie (Saint-Gobain, Paprec, Tournus Équipement), Services aux entreprises (Onet, Elis, Petit Forestier), Médias, Gaming & Entertainment (Dailymotion, Deezer, France Télécom).

### Exemple client : Isatis Capital

- 8 missions depuis 2012 (5 DD pour Isatis, 3 missions pour ses participations) : Flexico (30,0 M€, DD d’acquisition 2012, chez Grant Thornton), SMS (5,0 M€, DD OBO 2014), Mediameeting (6,9 M€, DD 2015), Corso (6,0 M€, DD 2015), Germ’line (6,4 M€, DD capital dév. 2017), Mediameeting (3,9 M€, VDD 2020), Mediameeting (9,1 M€, accompagnement 2022), Projet Sirona (0,7 M€, DD 2026).
- 6 thématiques et références comparables : textes de la page 11 de l’exemple.
- Photo de la page Mission : `photos-citation/frederic-cyril-cour-degrade.jpg` (citation de Frédéric).
- Secteur prioritaire : ESN, digital & logiciels.

## Prez Financement des startups (V4 validée le 29/10/2026)

Gabarit complet : `gabarits/prez/prez-financement-startups.html` ; aperçu : PDF dans les fichiers du projet, planche `apercus/Prez_Financement_startups_V4-planche.jpg`. Sources : pages « Financement des startups » et « Subventions & aides » de supercapital.fr. Les textes ci-dessous sont des reformulations du site validées.

- **Couverture** : « /Financement des startups/ », sous-titre « Aides à l’innovation, subventions et dette bancaire, jusqu’au décaissement ». Étiquettes : « Financement des startups » (https://www.supercapital.fr/expertises/financement-startups) et « Subventions & aides » (https://www.supercapital.fr/expertises/subventions-aides).
- **Mission** : vignette « /Notre mission/ », titre « /Sécurisons le financement de votre innovation/ » (« innovation » en orange). Texte : « Un seul interlocuteur pour actionner tous vos leviers de financement non dilutif. Subventions, dette bancaire, BPI France, crédit d’impôt : nous structurons, négocions et maximisons votre financement jusqu’au décaissement. » Citation de Gaspard de Buchet.
- **Chiffres** : 60 M€ levés pour nos clients startup ; 250+ entrepreneurs accompagnés ; 200+ startups dans notre portefeuille (chiffres officiels du marché startup). Chiffres du site non officiels, non utilisés : 98 % de réussite, +30 M€ par an, 64 % de levier, +200 clients.
- **Offre** : vignette « /Nos leviers/ », titre « /Un seul interlocuteur pour tous vos leviers non dilutifs ». Code couleur : Aides à l’innovation orange, Subventions & aides bleu, Dette bancaire bordeaux.

### Leviers (accroches, blocs et dispositifs)

| Levier | Accroche | Blocs : dispositifs (montants) |
|---|---|---|
| Aides à l’innovation | Accélérer votre R&D avec des prêts ou des aides remboursables seulement en cas de succès. | Création : Bourse French Tech ou Innov’up (jusqu’à 30 000 €), Subvention Innovation (jusqu’à 50 000 €), Prêt d’honneur (50 000 € par associé). Innovation : Prêt Innovation R&D (jusqu’à 3 M€), avance remboursable (jusqu’à 200 000 €), Innov’up (jusqu’à 500 000 €). Croissance : Prêt d’amorçage (50 000 à 100 000 €), Prêt d’amorçage investissement (100 000 € à 2 M€), assurance prospection (65 % des dépenses). |
| Subventions & aides | Des subventions pour vos projets d’avenir. | Deeptech : Bourse French Tech Emergence (jusqu’à 90 000 €), Aide au développement deeptech (jusqu’à 2 M€), i-Lab (jusqu’à 600 000 €), i-Nov (projets de 1 à 5 M€). Régions & impact : Innov’up (jusqu’à 500 000 € de subventions), subventions régionales (50 000 à 500 000 €), ADEME (jusqu’à 1 M€). Européennes : financements européens (jusqu’à 10 M€), Eureka (jusqu’à 3 M€), EIC, Horizon Europe, Eurostars (seul ou en consortium). |
| Dette bancaire | Le financement bancaire adapté à chaque étape de la vie de votre entreprise. | Court terme : crédit de campagne, billet de trésorerie, affacturage. Moyen terme : prêts classiques (sur 36 à 48 mois, souvent en pool bancaire), prêt aligné sur la Bourse French Tech (30 000 à 50 000 €). Stock et immobilier : financement de stock (prêt garanti par un gageur externe), immobilier (prêt long terme ou crédit-bail). |

Intros des blocs : voir le gabarit. Corrections du site à ne pas recopier : i-Démo « 2 000 000 à 4 000 000 M€ », montants à l’anglaise (« 10,000,000 € »), « un fois », « première levier », « afin de manquer aucune opportunité ».

### Méthode (P-FRISE)

Titre « /Du premier rendez-vous au décaissement », vignette « /Notre process/ » : 1. Cadrage de la stratégie ; 2. Montage du dossier ; 3. Présentation aux financeurs ; 4. Négociation & décaissement (textes dans le gabarit).

### Témoignages (P-TEMOIGNAGES)

Titre « /Là où nous avons fait la différence », vignette « /Témoignages/ » : Léonard Grynfogel (Co-fondateur & CEO @ Luniwave), Paul Rousseau (Co-fondateur & CEO @ Bloomcare), Jérôme Bourreau (Fondateur & CEO @ Anamnèse), citations validées ci-dessus ; vignettes `extraits-references-2026/temoignages/p09-188.jpg` à `p09-190.jpg`.

### Références startup (rangée « Marché startup » de Groupe 08)

| Secteur | Startups |
|---|---|
| AI & Software | arcads, Cobl, bravas, Ordalie, shipfix |
| Retail & E-commerce | Nectargo, Debongout |
| Finance & Assurance | Goodvest, Faktus, Aria, alinea |
| Industrie & Énergie | Reekom, Tetmet, Elax Energie, Ex9 |
| Aérospatial & Défense | SpaceLocker |
| Services aux entreprises | TeamOut, fairjungle, jeudimerci, Fleex |
| Médias, Gaming & Entertainment | Kayros, Mangas.io, flagcat |
| Santé | Primaa, Kimialys, Be Liver, Austral Dx, Generare |

Titre « /Des compétences sectorielles variées », vignette « /Nos références/ », bandeau « Ils nous ont fait confiance ».

### Contact

Gaspard de Buchet seul (Responsable marché startup, gaspard@supercapital.vc, +33 7 83 20 15 68), en version agrandie.


## Prez Reprise (V2 validée le 04/11/2026, Claude Slides)

Aperçu : `apercus/Prez_Reprise_V2_validee.pdf` ; slides : `gabarits/claude-slides/`.

### Mission (slide 02)

« De l’opportunité à la signature, nous orchestrons chaque étape de votre reprise à vos côtés : LOI, audit, négociation, montage financier, levée de financements. »

### Chiffres marché — source : Le Lab BPI France, « Transmission et reprise d’entreprise – Perspectives de marchés et facteurs clés de succès », novembre 2025

| Chiffre | Libellé |
|---|---|
| 40 % | Des dirigeants de TPE, PME et ETI comptent transmettre d’ici 4-5 ans (étude : « dans les cinq prochaines années ») |
| ~370 000 | TPE, PME et ETI à transmettre d’ici 2030 (somme exacte des catégories : 369 200, arrondie par l’étude) |
| 310 000 / 58 000 / 1 200 | TPE (1 à 9 salariés) / PME (10 à 249 salariés) / ETI |
| ~3 M | Emplois salariés potentiellement concernés : ~1 M en TPE, ~1,4 M en PME, ~610 000 en ETI |
| 10 / 19 / 39 / 32 % | Répartition par secteur : industrie / construction / commerce-transports-tourisme / services |
| 113 000 / 86 000 / 60 000 / 56 000 / 38 000 / 15 000 | Services (hors CTT) / commerce / tourisme / construction / industrie (dont 11 000 PME-ETI) / services de transport, à horizon 5 ans |
| 35 / 29 / 23 / 7 / 7 % | Profils de cédants : optimiste / qui a envie de changer d’air (plus jeune, sous pression au travail, projet post-cession) / préparé / reprise par les salariés / dans l’urgence |
| 42 / 31 / 10 / 9 / 8 % | Parcours de reprise : fluide et réussie / semée d’embûches (notamment financement) / familiale complexe / qui ne tient pas ses promesses / avec fonds d’investissement (valorisation supérieure, moins de difficultés) |
| 30 % | Des repreneurs citent le financement comme premier obstacle, surtout les ex-salariés |
| 57 % / 27 % | Des sources de financement d’une reprise sont bancaires / viennent de l’apport personnel |
| 70 % / 26 % | Ont atteint leurs objectifs à 5 ans / jugent a posteriori le prix de rachat trop élevé |
| 30 % / 41 % | Jugent les charges d’emprunt trop lourdes / des emprunteurs voient leurs investissements pénalisés |

Titres validés : « /Une vague de ~370 000 transmissions d’ici 2030 », « /Qui sont les cédants de demain ? », « /Faire partie des 42 % de reprises fluides et réussies ».

### Le constat → notre réponse (slide 06)

- Levée de dette et de capital : « 100+ banques et fonds partenaires, 2 000+ investisseurs engagés. »
- Ingénierie financière : « Leviers non-dilutifs (BPI France, crédit vendeur, OC) pour alléger l’apport du repreneur. »
- Analyse, valorisation & LOI : « Une valorisation juste, c’est une dette soutenable : due diligence et négociation pour reprendre au juste prix. »
- Un montage calibré : « Une dette dimensionnée sur la capacité de remboursement, pour préserver le développement. »
- Note club deal : « Les reprises adossées à un fonds d’investissement affichent une valorisation supérieure et moins de difficultés, mais ne représentent que 8 % des opérations. Notre club deal vous y donne accès. »

### Ingénierie financière, financement non-dilutif (slide 12)

- Publics & BPI France : « Prêts BPI France, garanties publiques, France Num, aides régionales et territoriales : plus de 40 M€ levés par an. » (chiffre retenu pour la prez Reprise, à reconfirmer ailleurs)
- Privés : « Fonds de dette privée, structuration de pool bancaire. »
- Obligations convertibles : « OC et instruments hybrides pour optimiser la structure capital/dette et limiter la dilution immédiate. »
- Chef d’orchestre du montage : « Nous coordonnons l’ensemble (banques, fonds, partenaires publics) pour un closing sécurisé. »

### Pricing (slide 15) — transaction ≤ 2 M€ / 2-5 M€ / > 5 M€

| Étape | Sourcing par Super Capital | Sourcing par le repreneur |
|---|---|---|
| 1. Premières analyses, rédaction de la LOI, négociation | 2 840 / 3 325 / 3 740 € (forfait) | idem |
| 2. Due diligence financière | 4 740 / 6 640 / 9 480 € (forfait) | idem |
| 3a. Montage & levée des financements bancaires | 3 780 / 5 640 / 7 640 € (forfait) | 3 780 € + 2 % / 5 640 € + 1,5 % / 7 640 € + 1 % (forfait + success fees) |
| 3b. Levée de financements en capital (optionnel) | 6 % au succès sur capital levé | 6 % au succès sur capital levé (3a. obligatoire) |
| 4. Closing | 4 / 3 / 2 % au succès sur le montant de la transaction, déduit des forfaits déjà engagés en étapes 1 à 3 | 0 % |

### Couverture

Étiquettes (liens) : Reprise → /expertises/reprise-entreprise ; Fusion-acquisition → /expertises/fusion-acquisition ; Financement PME → /expertises/financement-pme ; Transaction services → /expertises/audit-ts. Sous-titre (deux lignes) : « Accompagnement financier et stratégique à la reprise individuelle de PME » / « Valeur de transaction : 1 à 5 M€ ».
