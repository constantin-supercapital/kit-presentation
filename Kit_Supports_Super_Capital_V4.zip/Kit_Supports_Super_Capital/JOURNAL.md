# Journal des versions du kit

## V4 — 04/11/2026 (prez Reprise, V1 PDF puis V2 validée dans Claude Slides)

- Livrable par défaut : Claude Slides (export PDF et PowerPoint). Ajout de `gabarits/claude-slides/` : les 17 slides validées, `deck.json` et un README (correspondance des assets à téléverser, gabarits).
- Catalogue : P-MARCHE-ORGA, P-MARCHE-PROFILS, P-MARCHE-REPONSE, P-VISION, P-INTERVENTION, P-PRICING créés et validés ; P-FRISE 6 étapes validée ; « Marché (Reprise 04) » remplacé.
- Charte : règle 6 (slash de la Mission en orange), règle 9 (étiquettes sans soulignement), règles 24 à 29 (blocs chiffres blancs, signature des citations, vignettes ajustées, slides chiffrées, tableaux, texte sur 2 lignes), section 4 (pattern en biais continu, cadrage des photos), section 8 (Claude Slides), 14 décisions, 11 refus, points en attente.
- contenus.md : « 50+ transactions », fonction de Charles Garcia (« Partner - Responsable marché PME »), citation de la slide Vision attribuée à Charles (à valider), section prez Reprise V2 (chiffres BPI France sourcés, textes, cartes de la slide 12, pricing, couverture).
- Assets : portrait d’Eric Werner (original et avec dégradé), photo d’intervention en haute définition, pattern orange en JPG et fond de couverture pour Claude Slides.
- Aperçus : `Prez_Reprise_V2_validee.pdf` + planche ; PDF DAF V8, Isatis V16 et Financement des startups V4 remplacés par leurs planches (originaux dans les fichiers du projet). PNG optimisés sans perte. Kit sous 25 Mo.

## V3.2 — 29/10/2026 (prez Financement des startups, V1 à V4)

- `prez-commerciale-gabarits.html` : 4 gabarits ajoutés (P-SERVICE variante dispositifs, P-FRISE, P-TEMOIGNAGES, P-SECTEURS 8 secteurs) ; P-CONTACTS corrigé (supercapital.fr et mention légale sur la même ligne de base, `.ligne-fin`), aussi dans `prez-ts-daf-gabarits.html`. Rendu des 8 pages DAF d’origine inchangé au pixel près.
- Ajout de `gabarits/prez/prez-financement-startups.html` (V4 validée, 11 pages) et `apercus/Prez_Financement_startups_V4.pdf`.
- Charte : règle 20 réécrite (plafond et marges, nombre libre quand on reprend Groupe 08), règles 21 à 23, photo Mission ouverte au responsable du marché, catalogue et squelette, 9 décisions, 6 refus, points en attente.
- contenus.md : citation de Gaspard de Buchet, section prez Financement des startups (textes, dispositifs et montants, méthode, témoignages, 30 startups par secteur).
- Assets : portrait de Gaspard (original + version recadrée avec dégradé), 32 logos monochromes (30 startups de Groupe 08, Luniwave, Stefia, Dynames, Biohive), masques sources de shipfix et Mangas.io.

## V3.1 — 28/10/2026 (prez TS & DAF pour Isatis Capital, V11 à V16)

- Exemple renommé `apercus/Exemple_TS_DAF_Isatis.pdf` (V16), comme dans les fichiers du projet ; `prez-ts-daf-gabarits.html` mis à jour (rendu identique à la V16).
- P-SERVICE : espace menthe de 28 px entre pattern et zone blanche sur toutes les pages service, y compris dans `prez-commerciale-gabarits.html` (classe `.esp`).
- P-MISSION : photo Frédéric + Cyril (`photos-citation/frederic-cyril-cour*.jpg`), dégradé à la courbe standard.
- P-EQUIPE : deux niveaux (associés en grand, équipe en secondaire sous le bandeau « +17 »), photos carrées.
- Logo Paprec refait (détails en réserve + contour).
- Charte : 4 décisions, 4 refus, photo de citation, logos à forme colorée ; contenus.md : bios (Cyril version longue, Alix et Théo courtes), accroche valeur ajoutée.

## V3 — 28/10/2026 (support d’origine : prez TS & DAF à temps partagé pour Isatis Capital, V1 à V10)

- Ajout de `gabarits/prez/prez-ts-daf-gabarits.html` : prez client en 15 pages, rendu identique à la V10 validée. Six nouveaux gabarits validés : P-CHIFFRES (Reprise 03), P-DEJA (Groupe 07), P-EQUIPE (Reprise 14), P-THEMES (Reprise 08), P-SYNTHESE (Groupe 06-07), P-OPERATIONS (Reprise 12). Variantes : P-COUV avec logo client, P-SERVICE « valeur ajoutée » avec espace menthe, P-CONTACTS empilés (classe `.seul` pour un contact unique).
- Brouillon P-CLIENTS (Groupe 10) conservé hors catalogue : page retirée de la prez.
- Charte : section 0 (squelette et catalogue), section 4 (logo client, pattern orange, logos à forme pleine), règles 17 à 20 (chiffres clés, titres de blocs, remontée du contenu, logos de références), rédaction (bios, vignettes), 16 décisions validées, 11 refus, points en attente.
- contenus.md : contact de Cyril Doukhan, bios validées (Frédéric, Cyril, Alix, Théo), section prez TS & DAF (chiffres clés, textes, track record, opérations, références des associés, exemple Isatis).
- Assets : pattern orange refait depuis l’original (l’ancien avait une bande blanche), logos Isatis en SVG, 22 logos de références monochromes (sur-menthe, sur-blanc, sur-orange) et leurs sources, photo d’équipe en couleur (`photos-evenements/equipe-cour-couleur.jpg`).
- Scripts : `logos.py` (monochrome + taille à poids visuel égal).
- `apercus/Prez_TS_DAF_template_V10.pdf` et sa planche.

## V2 — 28/10/2026 (support d’origine : prez DAF à temps partagé, V1 à V8)

- Projet recentré sur les présentations commerciales : méthode « déroulé validé avant la V1 », squelette type et catalogue des gabarits (charte, section 0).
- Ajout de `gabarits/prez/prez-commerciale-gabarits.html` : 7 gabarits validés, contenu d’exemple DAF V8 (rendu identique au pixel près à la V8 livrée).
- Charte : 17 décisions validées (titres, tiret orange 20 × 7 px, guillemets “ ”, code couleur des offres, patterns, logos clients, étiquettes cliquables, tarifs, durées…), section « À ne pas faire », points en attente mis à jour (dégradé sur photo tranché).
- contenus.md : citations en “ ”, section prez DAF (textes, objectifs, durées, tarifs, clients par secteur), question à réécrire, corrections à faire dans le CMS.
- Assets : patterns bleu et bordeaux, portrait de Frédéric (original + dégradé), 13 logos clients DAF.
- `_base.css` : trait des blocs remplacé par le tiret orange 20 × 7 px ; commentaire de `.accent` mis à jour.
- `rendu.py` : les ronds d’étape `.rond-p`, les sous-titres et les petits tirets ne sont plus signalés à tort.
- `apercus/Prez_DAF_temps_partage_V8.pdf` ajouté.

## V1 — 27/10/2026

- Première version : charte mesurée sur les prez Groupe et Reprise, contenus officiels, polices, assets, planche des composants, script de rendu.
