# Slides Claude Slides — prez Reprise V2 (validée le 04/11/2026)

17 slides au format Claude Slides : `deck.json` (ordre, sections, polices) et `slides/<id>.html` (une slide par fichier, éléments positionnés en px sur 1920 × 1080). Aperçu : `apercus/Prez_Reprise_V2_validee.pdf`.

## Réutiliser une slide dans une nouvelle prez

Les liens `/_blob/…` ne marchent que dans la prez d’origine. Dans une nouvelle prez Claude Slides, téléverser d’abord les fichiers ci-dessous comme assets, puis remplacer chaque `/_blob/…` par l’adresse renvoyée.

| `/_blob/` dans les slides | Fichier du kit |
|---|---|
| 7c7af857b55369e4e54e391a656d51f6 | `fonts/Satoshi-Medium.ttf` (famille « Satoshi Medium ») |
| 7c9f73a5ffd28cfba2cd373d768d5dfd | `fonts/Satoshi-Bold.ttf` (famille « Satoshi Bold ») |
| 9b0dcd9599c1ebed227560cd2483bf81 | `fonts/Sentient-Italic.ttf` (famille « Sentient Italic ») |
| f38277b367004fe0ed6beccabd736924 | `assets/logos/logo-horizontal-noir.svg` |
| 5718db11ac4cfba6ec9577fbcacda545 | `assets/logos/logo-horizontal-menthe.svg` |
| 41a514a06f7eea1fc797025436c18184 | `assets/pictos/fleche-diagonale-menthe.svg` |
| a2552af9ace3efabc74cbe623b4f401b | `assets/pictos/fleche-diagonale-noir.svg` |
| 90eb22652494f6af588aa02e2d748009 | `assets/claude-slides/pattern-orange.jpg` (pattern orange en JPG pour Claude Slides) |
| 6260b83fd4018c72e9ef12a1969fde23 | `assets/claude-slides/couverture-reprise-fond.jpg` (fond de couverture) |
| 882680e676ada88cf37545ad3e299e0c | `assets/photos-citation/eric-werner-portrait-degrade.jpg` |
| 7cd5e2fd5e58507517b70761dcbedcfd | `assets/photos-evenements/evenement-intervention-hd.jpg` |
| 180093f5987aad63cd7eb8d395a34d25 | `assets/photos-equipe/frederic-baecke.jpg` |
| 60a0513d212657f7fc3a4f0c3c3e3c40 | `assets/photos-equipe/charles-garcia.jpg` |
| 1ed90c1fe0000316d0aba7da1824c7d2 | `assets/photos-equipe/cyril-doukhan.jpg` |

## Gabarits contenus

| Fichier | Gabarit |
|---|---|
| cover | P-COUV (étiquettes cliquables, soulignement masqué par une bande de 5 px de la couleur de l’étiquette) |
| mission | P-MISSION (mot final et slash orange, signature de citation règle 25) |
| chiffres | P-CHIFFRES, 4 lignes |
| marche1 | P-MARCHE-ORGA |
| marche2 | P-MARCHE-PROFILS |
| marche3 | P-MARCHE-REPONSE |
| vision | P-VISION (panneau pattern en biais : pattern pleine largeur recouvert par le SVG menthe + blanc) |
| expertises | P-OFFRE, 4 cartes |
| process | P-FRISE 6 étapes, deux rangées décalées |
| interv-1-3, interv-4, interv-5-dette, interv-5-capital | P-INTERVENTION (blocs chiffres blancs, règle 24) |
| operations | P-OPERATIONS, 4 chiffres par opération, blocs blancs |
| pricing | P-PRICING |
| equipe | P-EQUIPE (Reprise 14, cases égales, bloc « +17 » blanc) |
| contacts | P-CONTACTS (deux contacts côte à côte) |
