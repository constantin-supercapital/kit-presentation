"""Vectorise un masque (logo, picto) en SVG avec potrace.
Les logos du kit ont été tracés depuis le logo transparent d'origine (IoU > 0,99).
Usage : python3 scripts/vectoriser.py masque.png sortie.svg [#couleur]
Dépendance : pip install potracer --break-system-packages
"""
import sys
import numpy as np
import potrace
from PIL import Image


def trace(mask_path, out_path, crop=None, scale=3, color="currentColor"):
    m = Image.open(mask_path).convert("L")
    if crop:
        m = m.crop(crop)
    W, H = m.size
    big = m.resize((W * scale, H * scale), Image.BICUBIC)
    arr = np.array(big) <= 127  # potracer trace les pixels « False »
    plist = potrace.Bitmap(arr).trace(turdsize=4, alphamax=1.0, opticurve=True, opttolerance=0.2)
    s = 1.0 / scale
    f = lambda p: f"{p.x * s:.2f},{p.y * s:.2f}"
    d = []
    for curve in plist:
        d.append("M" + f(curve.start_point))
        for seg in curve.segments:
            if seg.is_corner:
                d.append("L" + f(seg.c) + "L" + f(seg.end_point))
            else:
                d.append("C" + f(seg.c1) + " " + f(seg.c2) + " " + f(seg.end_point))
        d.append("Z")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">'
           f'<path fill-rule="evenodd" fill="{color}" d="{"".join(d)}"/></svg>')
    open(out_path, "w").write(svg)
    return W, H


if __name__ == "__main__":
    col = sys.argv[3] if len(sys.argv) > 3 else "#171B15"
    print(trace(sys.argv[1], sys.argv[2], color=col))
