"""Convertit les polices Satoshi OTF (CFF) en TTF (glyf) pour un rendu PDF fiable.
Usage : python3 scripts/otf2ttf.py fonts/otf/Satoshi-Bold.otf fonts/Satoshi-Bold.ttf
"""
import sys
from fontTools.ttLib import TTFont, newTable
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.ttGlyphPen import TTGlyphPen


def otf_to_ttf(src, dst, max_err=1.0):
    font = TTFont(src)
    assert font.sfntVersion == "OTTO" and "CFF " in font, "police OTF/CFF attendue"
    order = font.getGlyphOrder()
    gs = font.getGlyphSet()
    glyphs = {}
    for name in order:
        tt = TTGlyphPen(gs)
        gs[name].draw(Cu2QuPen(tt, max_err, reverse_direction=True))
        glyphs[name] = tt.glyph()
    font["loca"] = newTable("loca")
    font["glyf"] = glyf = newTable("glyf")
    glyf.glyphOrder = order
    glyf.glyphs = glyphs
    del font["CFF "]
    if "VORG" in font:
        del font["VORG"]
    glyf.compile(font)
    hmtx = font["hmtx"]
    for name, g in glyf.glyphs.items():
        if hasattr(g, "xMin"):
            hmtx[name] = (hmtx[name][0], g.xMin)
    font["maxp"] = maxp = newTable("maxp")
    maxp.tableVersion = 0x00010000
    for k in ("maxZones",):
        setattr(maxp, k, 1)
    for k in ("maxTwilightPoints", "maxStorage", "maxFunctionDefs", "maxInstructionDefs",
              "maxStackElements", "maxSizeOfInstructions", "maxComponentElements"):
        setattr(maxp, k, 0)
    post = font["post"]
    post.formatType = 2.0
    post.extraNames = []
    post.mapping = {}
    post.glyphOrder = order
    font["head"].glyphDataFormat = 0
    font.sfntVersion = "\000\001\000\000"
    font.save(dst)


if __name__ == "__main__":
    otf_to_ttf(sys.argv[1], sys.argv[2])
    print("OK", sys.argv[2])
