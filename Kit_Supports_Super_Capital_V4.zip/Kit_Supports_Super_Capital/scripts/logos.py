"""Logos clients et références : monochrome aplati + taille à poids visuel égal.

1. Monochrome : python3 scripts/logos.py mono source.png sortie.png [#fond] [#encre] [mode]
   - fond par défaut #E9F6F6 (menthe), encre #171B15 (noir) ; pour l’orange : #FE2E12 et #E9F6F6.
   - mode : auto (alpha, ou écart au fond des bords si l’image est opaque),
            nonwhite (garde tout ce qui n’est pas blanc : logos dans une boîte colorée, texte en réserve),
            dark (garde l’encre foncée), light (encre claire dans une boîte foncée).
   Les logos à forme pleine (pastille, carré plein) donnent une tache noire : les écarter.
2. Taille : python3 scripts/logos.py taille logo.png  → largeur × hauteur en px pour P-SECTEURS
   Surface corrigée par la densité d’encre : 8200 × (0,32 / densité)^0,6, plafonnée à 230 × 92 px.
   Décision validée le 28/10/2026 (prez TS & DAF V9) : même poids visuel, pas seulement même surface.
3. Logo client de couverture : vectoriser le masque (scripts/vectoriser.py) pour qu’il se pose
   sur le pattern sans rectangle ; noir sur fond clair, menthe sur fond foncé.
"""
import math, sys
import numpy as np
from PIL import Image

NOIR = '#171B15'


def _rgb(c):
    return np.array(Image.new('RGB', (1, 1), c).getpixel((0, 0)), float)


def masque(path, mode='auto'):
    a = np.asarray(Image.open(path).convert('RGBA')).astype(float)
    rgb, al = a[..., :3], a[..., 3] / 255
    lum = rgb @ [0.299, 0.587, 0.114]
    if al.min() > 0.98:
        bord = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]])
        d = np.sqrt(((rgb - np.median(bord, axis=0)) ** 2).sum(-1))
        al = np.clip((d - 25) / 80, 0, 1)
    if mode == 'dark':
        al = al * np.clip((170 - lum) / 80, 0, 1)
    elif mode == 'light':
        al = al * np.clip((lum - 120) / 80, 0, 1)
    elif mode == 'nonwhite':
        al = al * np.clip((235 - lum) / 40, 0, 1)
    return al


def mono(src, out, fond='#E9F6F6', encre=NOIR, mode='auto'):
    al = masque(src, mode)
    ys, xs = np.where(al > 0.06)
    al = al[ys.min():ys.max() + 1, xs.min():xs.max() + 1][..., None]
    img = _rgb(fond) * (1 - al) + _rgb(encre) * al
    Image.fromarray(img.round().astype('uint8')).save(out)


def taille(path):
    im = Image.open(path); w, h = im.size; r = w / h
    a = np.asarray(im.convert('L')).astype(float)
    dens = float(np.clip((233 - a) / 206, 0, 1).mean())
    aire = 8200 * (0.32 / dens) ** 0.6
    W, H = math.sqrt(aire * r), math.sqrt(aire / r)
    k = min(1, 230 / W, 92 / H)
    return round(W * k), round(H * k)


if __name__ == '__main__':
    if sys.argv[1] == 'mono':
        mono(*sys.argv[2:4], *(sys.argv[4:] or []))
    elif sys.argv[1] == 'taille':
        print(*taille(sys.argv[2]))
