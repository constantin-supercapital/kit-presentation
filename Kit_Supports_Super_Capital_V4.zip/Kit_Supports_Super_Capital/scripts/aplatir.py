"""Aplatit des logos transparents sur une couleur de fond unie (aucune transparence dans les PDF).
Usage :
  python3 scripts/aplatir.py logo.png sortie.png "#FFFFFF"
  python3 scripts/aplatir.py dossier_source/ dossier_sortie/ "#E9F6F6"   (traitement par lot)
Le fichier d'origine n'est jamais modifié.
"""
import os
import sys
from PIL import Image


def aplatir(src, dst, hexa):
    im = Image.open(src).convert("RGBA")
    fond = Image.new("RGBA", im.size, hexa)
    fond.alpha_composite(im)
    fond.convert("RGB").save(dst, optimize=True)


if __name__ == "__main__":
    src, dst, hexa = sys.argv[1], sys.argv[2], sys.argv[3]
    if os.path.isdir(src):
        os.makedirs(dst, exist_ok=True)
        for f in sorted(os.listdir(src)):
            if f.lower().endswith(".png"):
                aplatir(os.path.join(src, f), os.path.join(dst, f), hexa)
        print("OK", dst)
    else:
        aplatir(src, dst, hexa)
        print("OK", dst)
