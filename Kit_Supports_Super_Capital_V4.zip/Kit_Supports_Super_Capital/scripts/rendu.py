"""Rendu d’un gabarit HTML en PDF ou PNG avec Chromium (Playwright), avec contrôles automatiques.

Usage :
  python3 scripts/rendu.py gabarits/presentation-16x9.html sorties/Prez_V1.pdf
  python3 scripts/rendu.py gabarits/post-linkedin.html sorties/Post_V1.png       → Post_V1-1.png, -2.png…
  python3 scripts/rendu.py gabarits/carrousel-linkedin.html sorties/Carrousel_V1.pdf --png apercus/
Options :
  --pages 1,3,5   ne rendre que ces pages (numérotation à partir de 1)
  --png DOSSIER   exporte aussi chaque page en PNG (contrôle visuel)
  --echelle 2     facteur de résolution des PNG (1 = taille nominale)

Contrôles signalés (sans bloquer le rendu) :
  texte hors page ou rogné, mot trop long pour sa colonne, arrondis interdits,
  couleurs hors palette, deux blocs de la même couleur sur une page, photo manquante.
"""
import argparse
import asyncio
import pathlib
import sys

from playwright.async_api import async_playwright

PALETTE = {
    "rgb(233, 246, 246)": "menthe", "rgb(23, 27, 21)": "noir", "rgb(254, 46, 18)": "orange",
    "rgb(96, 25, 35)": "bordeaux", "rgb(159, 198, 255)": "bleu", "rgb(188, 203, 193)": "sauge",
    "rgb(0, 84, 45)": "vert", "rgb(112, 129, 59)": "olive", "rgb(255, 255, 255)": "blanc", "rgb(219, 219, 219)": "pointilles",
}

JS_CONTROLES = r"""
(palette) => {
  const msgs = [];
  const pages = [...document.querySelectorAll('.page')];
  pages.forEach((pg, i) => {
    const n = i + 1, R = pg.getBoundingClientRect();
    const blocs = {};
    pg.querySelectorAll('*').forEach(el => {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0 || cs.visibility === 'hidden') return;
      const txt = [...el.childNodes].filter(x => x.nodeType === 3).map(x => x.textContent).join('').trim();
      if (txt) {
        if (r.right > R.right + 1 || r.bottom > R.bottom + 1 || r.left < R.left - 1 || r.top < R.top - 1)
          msgs.push(`p.${n} : texte hors page « ${txt.slice(0, 45)} »`);
        if (el.scrollWidth > el.clientWidth + 2 && cs.display !== 'inline' && cs.whiteSpace !== 'nowrap')
          msgs.push(`p.${n} : mot trop long pour sa colonne « ${txt.slice(0, 45)} »`);
        if (!palette[cs.color]) msgs.push(`p.${n} : couleur de texte hors palette ${cs.color} « ${txt.slice(0, 30)} »`);
      }
      if ((cs.overflow === 'hidden' || cs.overflowY === 'hidden') && el !== pg && !el.classList.contains('photo')
          && !el.classList.contains('zone-pattern') && (el.scrollHeight > el.clientHeight + 2) && el.innerText.trim())
        msgs.push(`p.${n} : contenu rogné dans <${el.tagName.toLowerCase()} class="${el.className}">`);
      if (parseFloat(cs.borderTopLeftRadius) > 0 && !el.classList.contains('rond') && !el.classList.contains('rond-p'))
        msgs.push(`p.${n} : arrondi interdit sur <${el.tagName.toLowerCase()} class="${el.className}">`);
      if (cs.boxShadow !== 'none' || parseFloat(cs.opacity) < 1 || cs.backgroundImage !== 'none')
        msgs.push(`p.${n} : ombre, opacité ou image de fond CSS interdite sur .${el.className}`);
      const bg = cs.backgroundColor;
      if (bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
        if (!palette[bg]) msgs.push(`p.${n} : fond hors palette ${bg} sur .${el.className}`);
        if (bg === 'rgb(23, 27, 21)') msgs.push(`p.${n} : FOND NOIR interdit sur .${el.className}`);
        const nom = palette[bg];
        const parentBg = el.parentElement ? getComputedStyle(el.parentElement).backgroundColor : '';
        const ignore = nom === 'blanc' || nom === 'menthe' || el.tagName === 'I' || el.tagName === 'TD' || el.tagName === 'TH'
                       || parentBg === bg || el.classList.contains('trait') || el.classList.contains('sous-titre')
                       || (r.width < 60 && r.height < 20) || el.closest('.deborde-ok');
        if (nom && !ignore) (blocs[nom] = blocs[nom] || []).push(el.className || el.tagName);
      }
    });
    Object.entries(blocs).forEach(([nom, els]) => {
      if (els.length > 1) msgs.push(`p.${n} : ${els.length} blocs ${nom} sur la même page (${els.join(', ')})`);
    });
    pg.querySelectorAll('img').forEach(im => {
      if (!im.complete || im.naturalWidth === 0) msgs.push(`p.${n} : image introuvable ${im.getAttribute('src')}`);
    });
  });
  return msgs;
}
"""


async def rendre(src, out, pages=None, png_dir=None, echelle=1):
    src = pathlib.Path(src).resolve()
    out = pathlib.Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    async with async_playwright() as p:
        nav = await p.chromium.launch()
        pg = await nav.new_page(device_scale_factor=echelle)
        await pg.goto(src.as_uri())
        await pg.evaluate("document.fonts.ready")
        await pg.wait_for_load_state("networkidle")
        dims = await pg.evaluate("""() => { const p = document.querySelector('.page'); const r = p.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)]; }""")
        n = await pg.evaluate("document.querySelectorAll('.page').length")
        fonts = await pg.evaluate("[...document.fonts].filter(f => f.status === 'loaded').map(f => f.family + ' ' + f.weight)")
        if not any("Satoshi" in f for f in fonts):
            print("ATTENTION : Satoshi n’est pas chargée (vérifier le chemin ../fonts/)")
        if pages:
            await pg.evaluate("""(keep) => { document.querySelectorAll('.page').forEach((p, i) => { if (!keep.includes(i + 1)) p.remove(); }); }""", pages)
        await pg.set_viewport_size({"width": dims[0], "height": dims[1]})
        msgs = await pg.evaluate(JS_CONTROLES, PALETTE)
        w, h = dims
        if out.suffix.lower() == ".pdf":
            await pg.emulate_media(media="print")
            await pg.pdf(path=str(out), width=f"{w}px", height=f"{h}px", print_background=True,
                         margin={"top": "0", "right": "0", "bottom": "0", "left": "0"})
            print(f"PDF : {out} ({n if not pages else len(pages)} pages, {w}×{h})")
        if out.suffix.lower() == ".png" or png_dir:
            await pg.emulate_media(media="screen")
            d = pathlib.Path(png_dir) if png_dir else out.parent
            d.mkdir(parents=True, exist_ok=True)
            stem = out.stem
            els = await pg.query_selector_all(".page")
            for i, el in enumerate(els, 1):
                num = pages[i - 1] if pages else i
                f = d / f"{stem}-{num}.png"
                await el.screenshot(path=str(f))
            print(f"PNG : {len(els)} image(s) dans {d}/ ({w * echelle}×{h * echelle})")
        await nav.close()
    if msgs:
        print(f"\n{len(msgs)} point(s) à vérifier :")
        for m in dict.fromkeys(msgs):
            print("  -", m)
    else:
        print("Contrôles automatiques : rien à signaler.")
    return msgs


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("sortie")
    ap.add_argument("--pages")
    ap.add_argument("--png")
    ap.add_argument("--echelle", type=float, default=1)
    a = ap.parse_args()
    pages = [int(x) for x in a.pages.split(",")] if a.pages else None
    asyncio.run(rendre(a.source, a.sortie, pages, a.png, a.echelle))
