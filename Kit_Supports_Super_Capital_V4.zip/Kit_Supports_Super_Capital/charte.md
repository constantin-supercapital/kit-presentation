# Charte de production Super Capital — Kit V4 (04/11/2026)

Ce fichier est la source unique de vérité pour produire les supports Super Capital avec Claude.
**Le projet est dédié en priorité aux présentations commerciales** (format des prez Reprise et DAF à temps partagé). Carrousels, posts et visuels arrivent au compte-goutte : leurs règles sont en section 12.

Ordre de priorité en cas de doute :

1. **Les références** : prez Reprise (version d’origine, et sa V2 validée le 04/11/2026 dans Claude Slides : `apercus/Prez_Reprise_V2_validee.pdf`), puis prez DAF à temps partagé (fichiers du projet ; planche dans `apercus/`), puis prez « Exemple_TS_DAF_Isatis » (fichiers du projet ; planche dans `apercus/`), puis prez Groupe. Pour les carrousels seulement : carrousel Innovation Fund V25.
2. **Cette charte** (les « Décisions validées » de la section 9 priment sur le reste de la charte).
3. **Le site supercapital.fr.**

Si une règle de cette charte contredit une référence, le signaler à Constantin au lieu de choisir seul.

---

## 0. Produire une prez commerciale

### Méthode (obligatoire)

1. Lire la prez source (Google Slides, PDF ou texte) et `contenus.md`.
2. **Avant toute mise en page**, proposer un déroulé slide par slide : contenu de chaque slide + gabarit ou slide de référence imitée (ex. « P-SERVICE (Reprise 05) »). Signaler les chiffres non officiels, les fonctions à corriger, les photos douteuses et les contenus manquants.
3. Attendre la validation du déroulé, puis produire la V1 **dans Claude Slides** (livrable par défaut depuis le 04/11/2026, exportable en PDF et PowerPoint), en partant des slides de `gabarits/claude-slides/` (prez Reprise V2) et des gabarits HTML `gabarits/prez/prez-commerciale-gabarits.html` (prez d’une offre) ou `gabarits/prez/prez-ts-daf-gabarits.html` (prez personnalisée pour un client, avec pages [PERSO]). Un fichier PDF ou PowerPoint n’est produit que sur demande (rendu HTML → PDF, section 8).
4. **Aucune mise en page inventée** : si aucun gabarit ni aucune slide de référence ne convient, demander.

### Squelette type

| Ordre | Slide | Gabarit |
|---|---|---|
| 01 | Couverture | P-COUV |
| 02 | Mission / légitimité avec citation | P-MISSION |
| 03 | Chiffres clés (si chiffres officiels disponibles) | P-CHIFFRES |
| 04-06 | Marché (si étude sourcée) : potentiel, cibles, constat face à notre réponse | P-MARCHE-ORGA, P-MARCHE-PROFILS, P-MARCHE-REPONSE |
| 04 | Offre en un coup d’œil | P-OFFRE |
| 05+ | Services détaillés (une slide par offre) | P-SERVICE (questions clients ou variante dispositifs), ou Reprise 08-09 pour un process par étapes |
| — | Méthode | P-FRISE (Reprise 07), ou fusionnée dans P-TARIFS |
| — | Témoignages clients | P-TEMOIGNAGES (Groupe 09) |
| — | Références clients par secteur | P-SECTEURS (prez d’une offre) ou P-SECTEURS 8 secteurs (prez d’un marché) |
| — | Offres et tarifs | P-TARIFS, ou Reprise 13 (tableau) si plusieurs grilles |
| — | Équipe | P-EQUIPE |
| — | Prez client : missions déjà réalisées, thématiques du client, synthèse des secteurs, opérations marquantes | P-DEJA, P-THEMES, P-SYNTHESE, P-OPERATIONS |
| Fin | Contacts | P-CONTACTS |

### Catalogue des gabarits

| Code | Page | Référence | Statut |
|---|---|---|---|
| P-COUV | Couverture | Reprise 01 | Gabarit validé |
| P-MISSION | Mission / légitimité, citation sur photo | Reprise 02 | Gabarit validé |
| P-OFFRE | Cartes d’offre | Reprise 06 | Gabarit validé |
| P-SERVICE | Service détaillé, panneau pattern en slash, espace menthe de 28 px | Reprise 05 | Gabarit validé (3 couleurs) |
| P-SECTEURS | Secteurs et logos clients | Groupe 08 | Gabarit validé |
| P-TARIFS | Offres numérotées, durées et tarifs | Créé sur DAF V8 | Gabarit validé |
| P-CONTACTS | Contacts | Groupe 12 | Gabarit validé |
| P-CHIFFRES | Chiffres clés + photo d’équipe | Reprise 03 | Gabarit validé (TS & DAF V16) |
| P-DEJA | Missions déjà réalisées pour le client | Groupe 07 | Gabarit validé (TS & DAF V16) |
| P-EQUIPE | Équipe en cases égales | Reprise 14 | Gabarit validé (TS & DAF V16) |
| P-THEMES | Thématiques du client, cartes à liseré | Reprise 08 | Gabarit validé (TS & DAF V16) |
| P-SYNTHESE | Synthèse des secteurs (10 cartes chiffres) | Groupe 06-07 | Gabarit validé (TS & DAF V16) |
| P-OPERATIONS | Opérations marquantes | Reprise 12 | Gabarit validé (TS & DAF V16) |
| P-SERVICE dispositifs | Levier détaillé : 3 blocs avec intro + dispositifs (nom gras, montant) | Reprise 05 | Gabarit validé (Financement des startups V4) |
| P-FRISE | Méthode en 4 étapes sur une rangée | Reprise 07 | Gabarit validé (Financement des startups V4) ; 6 étapes en deux rangées décalées validées (Reprise V2) |
| P-TEMOIGNAGES | 3 témoignages vidéo + citations | Groupe 09 | Gabarit validé (Financement des startups V4) |
| P-SECTEURS 8 | Références d’un marché, 8 secteurs de la prez Groupe | Groupe 08 | Gabarit validé (Financement des startups V4) |
| P-CLIENTS | Logos par catégorie (fonds, corporates) | Groupe 10 | Brouillon non validé (`brouillon-p-clients.html`) |
| P-MARCHE-ORGA | Marché : organigramme (chiffre clé → total → répartition en cartes) + colonne de chiffres | Créé sur Reprise V2 (slide 04) | Gabarit validé (Reprise V2, Claude Slides) |
| P-MARCHE-PROFILS | Marché : barre segmentée + chiffres à jauge fine, et graphique en anneau avec légende | Créé sur Reprise V2 (slide 05) | Gabarit validé (Reprise V2, Claude Slides) |
| P-MARCHE-REPONSE | Marché : anneau + tableau « Le constat / Notre réponse » | Créé sur Reprise V2 (slide 06) | Gabarit validé (Reprise V2, Claude Slides) |
| P-VISION | Vision : citation dans le panneau pattern + 4 blocs | Reprise 05 | Gabarit validé (Reprise V2, Claude Slides) |
| P-INTERVENTION | Intervention numérotée (ronds + ligne pointillée, cartes à liseré, blocs chiffres blancs) | Reprise 08-11 | Gabarit validé (Reprise V2, Claude Slides) |
| P-PRICING | Tableau de pricing à deux grilles | Reprise 13 | Gabarit validé (Reprise V2, Claude Slides) |
| — | Marché (bloc chiffre + 4 blocs texte) | Reprise 04 | Remplacé par les gabarits P-MARCHE |


Les gabarits validés sont dans `gabarits/prez/prez-commerciale-gabarits.html` (contenu d’exemple : prez DAF V8, puis les 4 gabarits de la prez Financement des startups V4) et `gabarits/prez/prez-ts-daf-gabarits.html` (contenu d’exemple : « Exemple_TS_DAF_Isatis », V16 validée), chacun précédé d’un commentaire `GABARIT …` qui résume ses règles. Exemple complet d’une prez d’offre en 11 pages : `gabarits/prez/prez-financement-startups.html` (V4 validée, PDF dans les fichiers du projet, planche dans `apercus/`). Slides Claude Slides validées (prez Reprise V2, 17 slides) : `gabarits/claude-slides/` (mode d’emploi dans son README).

---

## 1. Palette

| Rôle | Nom | Hex | Usage |
|---|---|---|---|
| Principale | Menthe | `#E9F6F6` | Notre « blanc » : fond par défaut, texte sur fonds foncés |
| Principale | Noir | `#171B15` | Texte uniquement, **jamais en fond** |
| Principale | Orange | `#FE2E12` | Couleur signature, formes prioritaires, tirets sous les titres de bloc |
| Secondaire | Bordeaux | `#601923` | Blocs, liserés, patterns, boutons sur fond orange |
| Secondaire | Bleu | `#9FC6FF` | Blocs, liserés, patterns (texte noir dessus) |
| Secondaire | Sauge | `#BCCBC1` | Sous-titres uniquement |
| Tertiaire | Vert | `#00542D` | Blocs, liserés, étiquettes |
| Tertiaire | Olive | `#70813B` | Blocs, liserés, étiquettes |
| Technique | Blanc | `#FFFFFF` | Cartes et zones blanches à fond perdu |
| Technique | Gris pointillés | `#DBDBDB` | Pointillés de structure uniquement |

Texte selon le fond : noir sur menthe, bleu, sauge et blanc ; menthe sur orange, bordeaux, vert et olive.

**Code couleur des offres** (liserés et patterns) : la première offre d’une prez en orange, la deuxième en bleu, la troisième en bordeaux. Exemple DAF : Gestion financière orange, Cash management bleu, Transaction services bordeaux. Le code reste le même d’une slide à l’autre.

## 2. Typographies

Fichiers : Drive **SUPER CAPITAL - MARKETING > 01. MARQUE > Couleurs & typographie**, et `fonts/` du kit (TTF pour les PDF + OTF d’origine).

| Police | Usage |
|---|---|
| **Satoshi Bold** | Titres, chiffres, titres de cartes et de blocs, étiquettes, citations sur photo |
| **Satoshi Medium** | Texte courant |
| **Sentient Italic** | Sous-titres « /Nos services/ », pagination « 02 / », signature des citations « /Frédéric BAECKE/ » |
| Sentient Bold | Réservée, non utilisée |

## 3. Échelles mesurées — prez 16:9 (1920 × 1080 px)

| Élément | Valeur |
|---|---|
| Marges gauche et droite | 108 px |
| Sous-titre (bloc sauge) | haut. 45 px, Sentient Italic 24 px, y ≈ 65 px |
| Titre de page | Satoshi Bold 64 px (56 px si deux lignes longues), interligne 1,19, MAJUSCULES, y ≈ 130 px |
| Titre de couverture | Satoshi Bold 96 px, menthe sur pattern |
| Texte courant | Satoshi Medium 21,3 px, interligne 28 px (18 à 20 px dans les cartes) |
| Titre de carte ou de bloc | Satoshi Bold 27 px, MAJUSCULES |
| **Tiret sous un titre de bloc** | **20 × 7 px, orange** (ratio ≈ 3 pour 1, mesuré sur les prez Groupe et Reprise) |
| Carte | blanche, liseré haut 6 px, gouttière 18 à 28 px |
| Citation sur photo | Satoshi Bold 42,7 px, MAJUSCULES, menthe, entre “ ” |
| Rond d’étape | 64 px (frise) ou 42 px (carte numérotée), contour noir 2 px |
| Logos clients | même surface visuelle ≈ 7 600 px², plafond 200 × 80 px |
| Étiquette de couverture | haut. 56 px, Satoshi Bold 22 px |
| Pied de page | logo horizontal noir 154 px en bas à gauche, pagination à droite, bas à 51 px |
| Pagination | Sentient Italic 21,3 px, orange, « 02 / » |

## 4. Logo, patterns, photos, pictos

- **Logo** : uniquement la version horizontale plate, sur une ligne. Menthe sur l’orange, noir sur la menthe. SVG dans `assets/logos/`.
- **Logo client (prez personnalisée)** : en couverture, en haut à droite, aligné sur le logo Super Capital (hauteur 92 px). Noir sur fond clair, blanc menthe sur fond foncé (orange compris). Toujours en SVG (`scripts/vectoriser.py` à partir du logo transparent) : une image aplatie laisse un rectangle visible sur le pattern.
- **Patterns** : toujours les fichiers d’origine, jamais redessinés en CSS. `Pattern_Orange4x.png` (couverture, contacts, panneaux), `Pattern_Bleu.png` et `Pattern_Bordeaux.png` (panneaux des offres 2 et 3). Les versions bleu et bordeaux du kit sont réduites à 1400 px pour alléger les PDF ; l’orange est réduit à 1960 px depuis l’original (l’ancienne version de 1400 px avait une bande blanche sur le bord droit). Originaux 8000 px sur le Drive.
- **Photos d’équipe** : photos carrées d’origine de `assets/photos-equipe/`, sans retouche ni détourage, sans couper un visage.
- **Photo sous une citation** : `assets/photos-citation/`. Slide Mission / Légitimité : portrait de Frédéric, ou portrait du responsable du marché de la prez avec sa propre citation validée (Gaspard de Buchet pour une prez startup : `gaspard-de-buchet-portrait-degrade.jpg`) ; pour une prez TS & DAF, photo de Frédéric et Cyril (`frederic-cyril-cour-degrade.jpg`). Ces portraits ne servent qu’à la slide Mission (les contacts gardent les photos carrées). Visages centrés horizontalement et dans le tiers supérieur, dégradé sombre intégré à l’image (jamais en CSS), courbe standard : rien jusqu’à 45 % de la hauteur, puis fondu linéaire jusqu’à 88 % de noir (#171B15) en bas. Recadrage au format du panneau (1080 × 1224 px pour un portrait 1080 × 1350). Ne pas renforcer le dégradé.
- **Logos clients** : `assets/logos-clients/sur-menthe/` (prêts à poser sur la menthe ; depuis la V3.2, les 30 startups de la rangée « Marché startup » de Groupe 08 y sont), `sur-blanc/` et `sur-orange/`. Monochromes, aplatis sans transparence (`scripts/aplatir.py`). Les logos en forme pleine (carré, disque plein : Fnac, Grand Frais, Talend…) sont évités : ils écrasent la page. Un logo à forme colorée (globe, pastille) garde ses détails en réserve, avec un fin contour, plutôt qu’une silhouette noire (ex. Paprec).
- **Panneau pattern en biais** (P-SERVICE, P-VISION) : le pattern court sur toute la largeur du bandeau et c’est la bande menthe (28 px) puis la zone blanche qui le recouvrent en biais. Jamais de pattern coupé avant la diagonale, ni de filet orange au bord.
- **Cadrage des photos** : toujours centrées dans leur zone (même marge de chaque côté) et recadrées, jamais étirées.
- **Flèches** : ↗ diagonale (étiquettes, cartes de la page Services de la prez Groupe) et →, en SVG dans `assets/pictos/`.

## 5. Règles de mise en page

1. Jamais de fond noir : le noir sert uniquement au texte.
2. Angles droits partout. Seule exception : les ronds numérotés d’étapes (frise ou cartes numérotées).
3. Jamais deux blocs pleins de la même couleur sur une page. Les liserés de cartes peuvent se répéter quand ils codent une offre.
4. Sur les pages peu colorées, l’orange en priorité pour les formes.
5. Sur l’orange : texte et slashs en menthe, jamais de texte bordeaux.
6. **Titres** : MAJUSCULES, précédés d’un « / », sans slash de fermeture, entièrement en noir. Deux exceptions : la couverture (titre fermé par un slash) et la slide Mission / Légitimité (mot final **et slash de fermeture en orange**, depuis le 04/11/2026).
7. Sous-titres (« /Nos services/ ») : bloc sauge, Sentient Italic, posé au-dessus du titre, jamais dans un bloc.
8. **Blocs de texte** : titre en majuscules, tiret orange 20 × 7 px, puis le texte. Jamais de filet vertical collé à un texte.
9. **Étiquettes autorisées** : Startups, TS, Fiscalité, Capital risque, Subvention, Capital dév., DAF externalisé, PME, M&A, Reprise, et les **noms complets des offres** (ex. « Direction financière externalisée », « Transaction services »). Flèche ↗ devant. Sur une couverture, chaque étiquette d’offre est un lien cliquable vers la page de l’offre sur le site, **jamais souligné** (dans Claude Slides, qui souligne les liens d’office : bande de 5 px de la couleur de l’étiquette posée sous le mot).
10. Pas de traits ni de pointillés entre les items d’une liste.
11. Aucun élément absent des références : pas de légende, de bouton, de flèche sur les cartes, de bloc décoratif ou de mention ajoutée.
12. Logos clients classés selon les secteurs du site (CMS Webflow, collection References, champ Industrie), tous à la même surface visuelle.
13. Tarifs : jamais dans un aplat orange étiré. Prix alignés, taille modérée.
14. Durées au format unique : libellé « Durée estimée », chiffre en gras, précision courte.
15. Slide dense : retirer d’abord un chapeau secondaire plutôt que de réduire marges et interlignes.
16. Adresses e-mail autorisées seulement dans les prez commerciales confidentielles.
17. **Chiffres clés** : chiffre court (« 400+ », le plus après le chiffre) et libellé de 2 lignes au plus, aux tailles de Reprise 03 (96 px / 28 px). Jamais de phrase longue. Un chiffre issu du parcours des associés (et non de Super Capital) est attribué : « par nos associés ».
18. Les titres des blocs d’une même rangée ont le même nombre de lignes (coupure forcée si besoin, ex. « Spécialiste / Small Cap »).
19. Quand le titre tient sur une ligne, le contenu qui suit remonte : pas de vide sous le titre.
20. Logos de références : même poids visuel (surface corrigée par la densité d’encre, `scripts/logos.py taille`), plafonnés pour garder au moins 30 px de marge dans leur case (136 × 50 px dans une colonne de 8 secteurs), emplacements de même hauteur. Quand on choisit les logos (prez d’une offre), même nombre par colonne, emplacements alignés d’une colonne à l’autre. Quand on reprend une rangée de la prez Groupe (prez d’un marché), on garde ses logos et ses 8 secteurs : nombre libre par colonne, piles centrées.
21. Pages service d’une même prez : accroches de la même taille (27 px ; 44 px seulement si toutes les accroches de la prez sont courtes), terminées par un point ; titres de blocs sur le même modèle d’une page à l’autre (une ligne partout si possible, quitte à abréger).
22. Prez d’un marché (startup, PME) : références = rangée correspondante de la prez Groupe (slide 08), avec ses 8 secteurs.
23. Pied des contacts : « supercapital.fr » et la mention légale sur la même ligne de base (`.ligne-fin`).
24. **Blocs chiffres des slides intérieures** : fond blanc, chiffre et tiret en orange, sous-texte en noir (blocs « 65-80 % », « 2 000+ », « +17 », bloc total d’un organigramme). Blocs d’opérations : fond blanc, nom et type en orange, description en noir. Restent orange : couverture, contacts, panneaux pattern. Cette règle prime sur les PDF de référence.
25. **Signature des citations** : « /Prénom NOM/ » en Sentient Italic, environ 1,25 fois la taille de la fonction (23 px sur photo, 20 px dans un panneau) ; 6 px dessous, la fonction en capitales Satoshi Bold, interlettrage 0,6 px (18 px sur photo, 16 px dans un panneau). Fonction en sauge sur une photo, en menthe sur l’orange.
26. **Vignettes sauge** : largeur ajustée au texte, même marge de 18 px à gauche et à droite (mesurer le texte en Sentient Italic 24 px, + 36 px).
27. **Slides chiffrées (marché, étude)** : titre qui porte le message ; graphiques de la source repris aux codes de la marque (organigramme, barre segmentée fine, anneau, chiffres à jauge fine), un seul accent orange sur le chiffre ou la catégorie clé, le reste en noir et sauge ; arrondis affichés (« ~370 000 », « ~1 M ») ; source en bas de page ; argumentaire tourné vers la structuration du financement, spécialité de Super Capital.
28. Tableaux : jamais de case colorée vide (en-tête de colonne de libellés laissé transparent).
29. Texte d’une bande ou d’un bloc large : 2 lignes au plus.

## 6. Composants (`gabarits/_base.css` + gabarits prez)

| Classe | Composant |
|---|---|
| `.page.f-pres` / `.f-car` / `.f-post` / `.f-mini` | Formats |
| `.sous-titre` | Bloc sauge en Sentient Italic |
| `.titre`, `.titre-couv`, `.accent` | Titres (`.accent` uniquement sur la slide Mission) |
| `.bloc` (h3 + `.trait`) / `.tiret` | Bloc de texte avec tiret orange 20 × 7 px |
| `.carte .c-orange` / `.c-bleu` / `.c-bordeaux` | Carte blanche à liseré |
| `.bloc-c.orange` / `.bordeaux` / `.bleu`… | Bloc de couleur |
| `.etiquette .t-…` (en `<a href>` sur une couverture) | Étiquette |
| `.rond`, `.rond-p` | Ronds d’étape (64 px, 42 px) |
| `.zone-pattern` + `img.pattern` | Fond pattern |
| `.panneau`, `.zone-blanche`, `.accroche`, `.blocs .blk` | Slide P-SERVICE (dans le gabarit prez) |
| `.sect5`, `.bande`, `.cell-l` | Slide P-SECTEURS |
| `.offres`, `.tete`, `.obj`, `.duree`, `.tarifs-l` | Slide P-TARIFS |
| `.blocs.l1`, `.blk .chap`, `.blk .disp` | P-SERVICE variante dispositifs |
| `.frise4`, `.frise4-ligne` | P-FRISE |
| `.temo` | P-TEMOIGNAGES |
| `.sect8`, `.sl` | P-SECTEURS 8 secteurs |
| `.ligne-fin`, `.contact.seul` | Pied des contacts, contact unique agrandi |
| `.pied`, `.pagination`, `.pointilles-h`, `.pointilles-v` | Repères de page |

## 7. Rédaction

- Français soigné : « 2,6 M€ », espace insécable avant « : ; ? ! », apostrophes ’.
- **Guillemets** : “ ” pour les citations et les questions clients ; « » pour le reste du texte.
- « BPI France », jamais « Bpifrance » (sauf dans un logo).
- **Bios** : elles s’ouvrent sur l’expérience (« Fort de… », « Fort d’une expérience chez… »), jamais « Passé par ».
- **Vignettes** : en français et tournées vers le client (« /Notre expérience/ », « /Notre valeur ajoutée/ », « /À vos côtés depuis 2012/ »). Une date va dans la vignette, pas dans le titre.
- Fonctions, contacts, citations et chiffres : uniquement ceux de `contenus.md`. Ne jamais inventer un chiffre, un nom ou une citation. Toute reformulation d’un texte source est signalée à Constantin.

## 8. Rendu et contrôle

- **Claude Slides (par défaut)** : une slide par fichier HTML, éléments positionnés en px sur 1920 × 1080, polices Satoshi Medium, Satoshi Bold et Sentient Italic déclarées comme trois familles (pas de faux gras), images et polices téléversées comme assets. Vérifier chaque slide en aperçu avant de livrer. Les exports PDF et PowerPoint se font depuis Claude Slides.
- Rendu HTML → PDF/PNG avec Chromium : `python3 scripts/rendu.py gabarits/prez/ma-prez.html sorties/Prez_V1.pdf --png sorties/png/`.
- Polices en TTF, images en `<img>`, logos et pictos en SVG. Aucun dégradé, ombre, opacité ou motif CSS dans les PDF.
- Le script signale : texte hors page ou rogné, mot trop long, arrondi interdit (sauf `.rond`, `.rond-p`), couleur hors palette, fond noir, deux blocs pleins de même couleur (sous-titres et petits tirets exclus), image manquante.
- Contrôle visuel de chaque page avant livraison : débordements, visages coupés, contrastes, couleurs en double. Comparer au moins une page à sa référence.
- Fichiers versionnés (V1, V2…). Ne modifier que ce qui est demandé.

---

## 9. Décisions validées

| Date | Support | Décision | Raison |
|---|---|---|---|
| 28/10/2026 | Prez DAF à temps partagé | Chaque slide reprend la structure d’une slide de référence ; aucune mise en page inventée | La V1 « inventée » a été rejetée, la V2 calquée sur les références a été retenue |
| 28/10/2026 | Prez DAF | Déroulé slide par slide avec la référence imitée, validé avant la V1 | C’est l’étape qui a fait passer de la V1 à la V2 |
| 28/10/2026 | Prez DAF | Titres sans slash de fermeture, entièrement noirs ; exceptions : couverture (slash fermant) et slide Mission (mot final orange + slash noir ; slash passé en orange le 04/11/2026) | Sobriété des références |
| 28/10/2026 | Prez DAF | Tiret sous les titres de bloc : orange, 20 × 7 px | Mesuré sur les références ; le trait sauge et les tirets trop épais ont été refusés |
| 28/10/2026 | Prez DAF | Guillemets “ ” pour les citations et les questions clients | Choix de marque |
| 28/10/2026 | Prez DAF | Aucune mention « Propriétaire et confidentiel » | Absente des références |
| 28/10/2026 | Prez DAF | Aucun élément absent des références (légende, bouton, flèche sur carte, bloc décoratif) | Surcharge |
| 28/10/2026 | Prez DAF | Pas de traits ni de pointillés entre les items de liste ni au-dessus de la durée | Aération |
| 28/10/2026 | Prez DAF | Citation sur photo : visage centré, dégradé intégré à l’image, citation courte validée | Lisibilité ; tranche l’ancien point en attente sur le dégradé |
| 28/10/2026 | Prez DAF | Code couleur des offres orange / bleu / bordeaux, appliqué aux liserés et aux patterns ; texte noir sur le bleu | Repérage d’une slide à l’autre |
| 28/10/2026 | Prez DAF | Slides services sur le modèle Reprise 05 (panneau pattern en slash + zone blanche + 3 blocs) | Les cartes blanches étaient jugées « fades » |
| 28/10/2026 | Prez DAF | Logos clients monochromes, même surface visuelle, classés selon les secteurs du site | Cohérence avec le site, équilibre visuel |
| 28/10/2026 | Prez DAF | Étiquettes de couverture : noms complets des offres, cliquables vers le site | Le PDF renvoie au site |
| 28/10/2026 | Prez DAF | Ronds numérotés autorisés sur des cartes d’étapes (pas seulement les frises) | Rappel de la méthode en 3 étapes |
| 28/10/2026 | Prez DAF | Durées au format unique (libellé, chiffre gras, précision) | Lisibilité, comparaison |
| 28/10/2026 | Prez DAF | Tarifs sur une ligne sans aplat, prix alignés et de taille modérée, facturation jusqu’à la marge | Le bandeau orange et les grands prix ont été refusés |
| 28/10/2026 | Prez DAF | La photo portrait de Frédéric sert uniquement à la slide Mission / Légitimité | Format portrait ; les contacts gardent la photo carrée |
| 28/10/2026 | Prez TS & DAF (Isatis) | Chiffres clés : chiffre court + libellé de 2 lignes, tailles de Reprise 03 ; « 400+ » (plus après) | Les libellés en phrases forçaient à réduire les chiffres et cassaient le gabarit (V2 refusée) |
| 28/10/2026 | Prez TS & DAF | Chiffres issus du parcours des associés attribués « par nos associés » | Crédibilité face à un fonds : Super Capital a 8 ans |
| 28/10/2026 | Prez TS & DAF | Page chiffres : photo d’équipe en couleur, pas un portrait individuel en noir et blanc | Le collectif porte les chiffres |
| 28/10/2026 | Prez TS & DAF | Logo client en couverture en haut à droite, SVG ; noir sur fond clair, blanc menthe sur fond foncé | Co-branding lisible, règle 5 ; l’image aplatie laissait un rectangle |
| 28/10/2026 | Prez TS & DAF | Pattern orange réduit depuis le fichier d’origine | La version du kit avait une bande blanche à droite |
| 28/10/2026 | Prez TS & DAF | Accroche courte des pages service en 44 px dans le pattern ; accroche longue en 27 px | À 27 px, le panneau paraissait vide |
| 28/10/2026 | Prez TS & DAF | Page valeur ajoutée : espace menthe de 28 px entre le pattern et la zone blanche, comme Reprise 05 | Fidélité à la référence |
| 28/10/2026 | Prez TS & DAF | Titres de blocs d’une rangée sur le même nombre de lignes | Alignement des blocs |
| 28/10/2026 | Prez TS & DAF | Contenu remonté quand le titre passe sur une ligne | Pas de vide sous le titre |
| 28/10/2026 | Prez TS & DAF | Équipe en une rangée de cases égales (photos et bloc « +17 » de même taille), une bio par membre | Équilibre quel que soit le nombre de personnes ; la version « 2 grands + 2 petits » a été refusée |
| 28/10/2026 | Prez TS & DAF | Bios ouvertes sur l’expérience : « Fort de… » / « Fort d’une expérience chez… » | Pedigree lisible dès la première ligne ; choisi parmi 4 tournures |
| 28/10/2026 | Prez TS & DAF | Contacts empilés sous une seule vignette « /Contacts/ » ; un seul contact = photo et coordonnées agrandies, vignette inchangée | Remplir la page sans changer la structure |
| 28/10/2026 | Prez TS & DAF | Logos de références : poids visuel égal, emplacements alignés, colonnes complètes | « Bonnes proportions, bien alignés » (V9) |
| 28/10/2026 | Prez TS & DAF | Vignettes en français : « /Notre expérience/ », « /Notre valeur ajoutée/ », « /À vos côtés depuis [année]/ » | Ton client, pas d’anglicisme |
| 28/10/2026 | Prez TS & DAF | Code couleur : DD orange, VDD bleu, DAF bordeaux ; accompagnement vert sur les opérations | Une couleur par service, d’une slide à l’autre |
| 28/10/2026 | Prez TS & DAF | Références d’anciens employeurs (Grant Thornton…) présentées comme « sociétés accompagnées par nos associés au cours de leur carrière » | Honnêteté sur l’origine des références |
| 28/10/2026 | Prez TS & DAF (V16) | Espace menthe de 28 px entre pattern et zone blanche sur toutes les pages P-SERVICE (gabarit DAF compris) | Fidélité à Reprise 05 |
| 28/10/2026 | Prez TS & DAF (V16) | Photo de la page Mission : duo Frédéric + Cyril possible, visages dans le tiers supérieur, dégradé à la courbe standard | Le dégradé renforcé (V11) a été refusé |
| 28/10/2026 | Prez TS & DAF (V16) | Page équipe à deux niveaux : associés en grand à gauche, équipe en secondaire à droite sous le bandeau « +17 », séparés par 80 px ; photos carrées ; noms alignés ; bios de longueurs proches (associés en 17 px) | « On ne comprend pas que Fred et Cyril sont les éléments importants » (V11) |
| 28/10/2026 | Prez TS & DAF (V16) | Logo à forme colorée : détails en réserve + contour | Paprec illisible en silhouette noire (V12) |
| 29/10/2026 | Prez Financement des startups (V4) | Slide Mission : portrait et citation du responsable du marché possibles (Gaspard de Buchet) | Incarner le marché de la prez ; assouplit la réserve du portrait de Frédéric |
| 29/10/2026 | Prez Financement des startups | Accroches des pages service à la même taille dans une prez (27 px), terminées par un point ; la décision « accroche courte en 44 px » ne vaut que si toutes les accroches sont courtes | La slide 6 en 44 px détonnait à côté des slides 5 et 7 (V1) |
| 29/10/2026 | Prez Financement des startups | Titres de blocs des pages service sur le même modèle d’une page à l’autre (une ligne) | Retour V1 sur la slide 6 (« même style, modèle et taille de titre ») |
| 29/10/2026 | Prez Financement des startups | Prez d’un marché : références de la rangée correspondante de Groupe 08, avec ses 8 secteurs | Retour V1 : récupérer les startups et les secteurs de la prez Groupe |
| 29/10/2026 | Prez Financement des startups | Logos de références à poids visuel égal, plafonnés (136 × 50 px), 30 px de marge, emplacements de 84 px ; nombre libre par colonne quand on reprend Groupe 08 | « Même proportion et de la marge pour que le visuel soit équilibré » (V2) |
| 29/10/2026 | Prez Financement des startups | Contacts : supercapital.fr et mention légale sur la même ligne de base | Retour V1 sur la slide 11 |
| 29/10/2026 | Prez Financement des startups | P-FRISE (Reprise 07) et P-TEMOIGNAGES (Groupe 09) créés en V1 et validés sans retouche | Fidèles aux références |
| 29/10/2026 | Prez Financement des startups | P-SERVICE variante dispositifs (intro + nom en gras + montant) pour une offre faite de dispositifs de financement | Validée sans retouche depuis la V1 |
| 29/10/2026 | Prez Financement des startups | Montants du site réécrits au format français (« 2 M€ », « 90 000 € ») et précisions absentes du site retirées | Pas de chiffre inventé, typographie française |
| 04/11/2026 | Prez Reprise (V2, Claude Slides) | Livrable par défaut : Claude Slides, exportable en PDF et PowerPoint | Choisi par Constantin pour retoucher et commenter directement les slides |
| 04/11/2026 | Prez Reprise | Étiquettes de couverture cliquables, sans soulignement | Le soulignement abîme le visuel ; les liens vers les offres restent utiles |
| 04/11/2026 | Prez Reprise | Slide Mission : mot final et slash de fermeture en orange | Remplace la décision du 28/10 (slash noir) |
| 04/11/2026 | Prez Reprise | Blocs chiffres intérieurs blancs, chiffre et tiret orange, sous-texte noir ; opérations : nom et type orange | Plus léger que les aplats orange et bordeaux ; prime sur les références |
| 04/11/2026 | Prez Reprise | Signature des citations : nom à peine plus grand que la fonction, fonction en capitales juste dessous (règle 25) | Modèle fourni par Constantin (capture « /Charles GARCIA/ ») ; nom jugé trop grand à 26-30 px |
| 04/11/2026 | Prez Reprise | Vignettes sauge ajustées au texte, marges égales | Le bloc débordait à droite (« /Notre vision/ ») |
| 04/11/2026 | Prez Reprise | Photos centrées dans leur zone, jamais étirées | Photo de la slide Mission décentrée puis déformée |
| 04/11/2026 | Prez Reprise | Pattern du panneau en biais continu jusqu’à la diagonale, sans filet | « Le pattern doit continuer et non se couper », puis « enlever ligne orange » |
| 04/11/2026 | Prez Reprise | Slides marché : titre-message, graphiques de l’étude simplifiés, un accent orange, arrondis affichés, source en bas | Retenu après cinq versions ; les graphiques multicolores et le tableau à jauges ont été refusés |
| 04/11/2026 | Prez Reprise | Argumentaire tourné vers la structuration du financement | « On vise surtout les repreneurs qui ont besoin de structurer leur financement, c’est notre spécialité » |
| 04/11/2026 | Prez Reprise | Le chiffre clé (40 %) s’intègre en tête de l’organigramme | Le bandeau détaché était « mal présenté » |
| 04/11/2026 | Prez Reprise | Fonction de Charles Garcia : « Partner - Responsable marché PME », partout | Choix de Constantin |
| 04/11/2026 | Prez Reprise | Prix non arrondis dans le pricing, mention « forfait » à la place du détail jours × TJM | Demande de Constantin |
| 04/11/2026 | Prez Reprise | Frise du process en 6 étapes sur deux rangées décalées (Reprise 07) | Validée sans retouche |

## 10. À ne pas faire

| Refus | Raison |
|---|---|
| Inventer une mise en page (V1 DAF) | Les références priment ; proposer le déroulé avant |
| Garder une photo non officielle d’un support d’origine | L’ancienne prez DAF montrait une image générée par IA à la place de Frédéric |
| Fermer les titres par un slash orange (hors couverture et Mission) | Refusé en V2 |
| Trait sauge sous les titres de bloc, ou tiret épais (34 × 12 px) | Refusés en V7 et V8 |
| Traits colorés au-dessus des titres des cartes d’offre | Ajoutés en V2, retirés en V4 |
| Bandeau orange pleine largeur pour les tarifs, puis bloc orange vertical | « Pas fan » (V3 et V5) |
| Prix en très grand (60 px) | « Beaucoup trop grand » (V5) |
| Tableau de tarifs condensé façon Reprise 13 pour une seule grille | « Proportions mauvaises, trop condensé » (V2) |
| Mention « Propriétaire et confidentiel » | Absente des références |
| Légende des catégories, bloc « Notre rôle », flèches et boutons sur les cartes | Inventés, supprimés en V2 |
| Rond numéroté et ligne verticale sur les slides services | Supprimés en V4 au profit d’un titre de page standard |
| Bandeau « Sous-secteurs » séparé, sous-secteurs sous les logos | Supprimés en V4 |
| Colonne de secteur sans aucun logo | Remplacée par les secteurs du site |
| Logos de tailles disparates | Uniformisés en V8 |
| Libellés de chiffres en phrases longues, chiffres réduits pour les caser | « Déforme le design, texte trop long » (TS & DAF V2) |
| « +15 » (plus devant le chiffre) | Format des références : « 15+ » |
| Chiffre du parcours des associés présenté comme celui de Super Capital | Incohérent avec les 8 ans de Super Capital |
| Portrait individuel en noir et blanc sur la page chiffres | Remplacé par la photo d’équipe en couleur (TS & DAF V2) |
| Logo client en image aplatie sur le pattern | Rectangle visible ; utiliser un SVG |
| Équipe avec 2 grandes photos et 2 petites | Déséquilibrée (TS & DAF V2), remplacée par des cases égales |
| Bios ouvertes par « Passé par » | « Pas une belle formulation » (TS & DAF V7) |
| Vignette « /Track record/ » | Anglicisme, remplacé par « /Notre expérience/ » |
| Page « Ils nous font confiance » avec des cadres en pointillés à la place des logos manquants | Page retirée (TS & DAF V2) ; brouillon conservé hors catalogue |
| Version réduite du pattern orange avec bande blanche | Couverture non couverte bord à bord (TS & DAF V4) |
| Dégradé renforcé sur la photo de citation | Refusé en V12, retour à la courbe standard |
| Équipe en rangée de cases égales, associés et équipe confondus | Hiérarchie illisible (V11) |
| Photos d’équipe recadrées en paysage | Refusé en V14 : photos carrées uniquement |
| Logo coloré converti en silhouette noire pleine | Illisible (Paprec, V12) |
| Accroche courte en 44 px à côté d’accroches en 27 px dans la même prez | « Même style, modèle et taille » (Financement des startups V1) |
| Titres de blocs sur deux lignes sur une page quand les autres pages en ont une | Même retour (V1) |
| Références choisies une à une sur le site, sur 5 secteurs, pour une prez de marché | Remplacées par la rangée de Groupe 08 et ses 8 secteurs (V2) |
| Logos à poids égal mais sans plafond ni marge (logos qui frôlent les pointillés) | Déséquilibré (V2) |
| Mention légale décalée par rapport à supercapital.fr | Corrigé en V2 |
| Gris de la référence pour les fonctions (témoignages) | Hors palette : noir |
| Bande « Ce que ça change pour vous » en bas d’une slide | « Pas sûr que cela soit utile », retirée des slides marché (Reprise V2) |
| Jauges ou mention explicative ajoutées à un graphique, tableau croisé à jauges | « Je ne comprends toujours pas, est-ce vraiment utile ? » (Reprise V2) |
| Chiffre clé en bandeau détaché du schéma | « Mal présenté », puis « J’aime pas le visuel » |
| Graphiques en barres et anneaux multicolores façon rapport d’étude | Pas assez « fins » ni « en lien avec la marque » |
| Colonne « Ce qui fait échouer une reprise » pour des constats neutres | « Ce n’est pas un échec » : colonne « Le constat » |
| Texte de bloc ou de bande sur 3 lignes | « Attention sur le 2 lignes » |
| Pattern coupé net avant la diagonale ; filet orange entre le pattern et la zone blanche | Retours sur la slide Vision |
| Nom de la signature plus grand que la fonction de plus d’un quart | « Le prénom est encore trop grand » |
| Liens soulignés (soulignement d’office de Claude Slides) | « Pas de ligne soulignée pour les liens » |
| Case sauge vide en tête de tableau | Abîme le visuel (pricing) |

## 11. Points en attente

- Prez Financement des startups : « 64 % de levier » (site) non officiel, non utilisé ; à valider pour les prochaines prez startup.
- Logos manquants pour une prez startup choisie sur le site : Bloomcare, Reev, Primmo AI, Firecell, Stairling, Base for Music. Logo Mangas.io en basse définition (128 px) : original à demander.
- Fiscalité de l’innovation (CIR, CII, JEI) : prez dédiée ou 4e levier (quelle couleur ?) à décider.

- Prez TS & DAF : source du « 15+ secteurs » à confirmer.
- Prez TS & DAF : orthographe officielle d’« AYA Partners » et nom complet d’« Allianz Global » (Allianz Global Investors ?) à confirmer.
- Prez TS & DAF, page 04 : vide en bas de page ; agrandir les cartes si Constantin le souhaite.
- Prez TS & DAF : la virgule de l’accroche valeur ajoutée (« investisseurs, financiers ») crée quatre publics au lieu de trois ; enregistrée telle quelle.

- Prez Reprise V2 : citation de la slide Vision attribuée à Charles Garcia, à faire valider par Charles.
- Prez Reprise V2 : « 50+ transactions » et « plus de 40 M€ levés par an » retenus pour la prez Reprise ; à reconfirmer avant de les étendre à d’autres prez.
- Prez Reprise V2 : titre « 40 ans d’expérience cumulée » plus faible que les bios (près de 20 ans + plus de 30 ans).
- Prez Groupe, slide équipe : « Chargée d’affaires » sous Alexis Mercier, à vérifier.
- Prez Reprise, couverture : « Fusion-acquisition », « Financement PME », « Transaction services » sont des noms complets d’offres, donc désormais autorisés ; à harmoniser avec les noms exacts des pages du site si la couverture est refaite.

## 12. Autres supports (au compte-goutte)

### Carrousel LinkedIn (1080 × 1350 px, PDF) — référence : carrousel Innovation Fund V25

| Élément | Valeur |
|---|---|
| Marges gauche et droite | 90 px |
| Nom de la série (en-tête droite) | Satoshi Bold 23 px, « /INNOVATION FUND 2026 / » |
| Titre de page | Satoshi Bold 68 px |
| Accroche de couverture | hiérarchie de 3 tailles : S 66 px / XL 250 px / M 84 px |
| Texte | 26 px (34 px en couverture), secondaire 22 px |
| Étiquette | haut. 56 px, Satoshi Bold 28 px, flèche ↗ devant |
| Sous-titre (bloc sauge) | haut. 40 px, Sentient Italic 21 px |
| Pagination | Sentient Italic 24 px, en bas à gauche, « 01 / » |

### Post LinkedIn (1200 × 1500 px, PNG)

Mêmes proportions que le carrousel, multipliées par 1,11. Pas d’adresse e-mail sur les supports publics.
